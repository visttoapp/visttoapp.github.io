/* Vistto · Forno — projeto do Supabase e schema onde o Vistto foi instalado.
   A chave publicável é pública por natureza (vai para o navegador). Nunca coloque aqui a service_role/secret. */
window.CONFIG = { SUPABASE_URL: "https://pbmyudlawyyqfpnswgqt.supabase.co", SUPABASE_ANON_KEY: "sb_publishable_GOHvyublV0oaiGqRqlrrvA_t_kKjLsL", DB_SCHEMA: "vistto" };
