-- =====================================================================
--  VISTTO · FORNO — instalação completa do banco (rode uma vez só)
--  Supabase › SQL Editor › New query › cole este arquivo inteiro › Run
--
--  Tudo fica no schema "vistto", separado das tabelas do taskmanager (schema public).
--  Nada do public é criado, alterado ou apagado. Os logins (auth.users) são os mesmos.
--  Só existe uma agência: a Forno (id 10000000-0000-4000-8000-000000000002).
--  Depois de rodar: Project Settings › Data API › Exposed schemas › acrescente "vistto".
-- =====================================================================
create schema if not exists vistto;
grant usage on schema vistto to anon, authenticated, service_role;
alter default privileges in schema vistto grant all on tables to anon, authenticated, service_role;
alter default privileges in schema vistto grant all on sequences to anon, authenticated, service_role;
alter default privileges in schema vistto grant all on functions to anon, authenticated, service_role;
-- nomes sem schema caem no vistto; o public (taskmanager) fica fora do caminho de propósito
set search_path to vistto, extensions;
begin;
-- =====================================================================
--  VISTTO — schema do Supabase
--  Cole este arquivo inteiro em: Supabase › SQL Editor › New query › Run
-- =====================================================================

create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

-- ---------- tabelas ----------
create table if not exists clientes (
  id         uuid primary key default gen_random_uuid(),
  slug       text unique not null,          -- ex.: cliente-exemplo
  nome       text not null,                 -- Nome do cliente
  handle     text,                          -- @cliente
  bio        text,
  avatar_url text,
  token      text unique not null default encode(extensions.gen_random_bytes(12), 'hex'), -- vai no link do cliente
  created_at timestamptz default now()
);

create table if not exists meses (
  id         uuid primary key default gen_random_uuid(),
  cliente_id uuid not null references clientes(id) on delete cascade,
  ano_mes    text not null,                 -- 2026-09
  titulo     text not null,                 -- Setembro 2026
  intro      text,
  publicado  boolean default false,         -- só aparece pro cliente quando true
  created_at timestamptz default now(),
  unique (cliente_id, ano_mes)
);

create table if not exists posts (
  id         uuid primary key default gen_random_uuid(),
  mes_id     uuid not null references meses(id) on delete cascade,
  ordem      int not null default 0,        -- ordem de postagem
  numero     text,                          -- "01"
  data       text,                          -- "09/10" (texto livre)
  tema       text,
  titulo     text,
  tipo       text not null default 'carousel' check (tipo in ('carousel','image','reel')),
  legenda    text,
  slides     jsonb not null default '[]',   -- ["https://.../p01-1.jpg", ...]
  video_url  text,
  capa_url   text,
  status     text not null default 'pendente' check (status in ('pendente','aprovado','ajuste')),
  created_at timestamptz default now()
);

create table if not exists destaques (
  id         uuid primary key default gen_random_uuid(),
  cliente_id uuid not null references clientes(id) on delete cascade,
  ordem      int default 0,
  nome       text not null,
  capa_url   text
);

create table if not exists aprovacoes (
  id         uuid primary key default gen_random_uuid(),
  post_id    uuid not null references posts(id) on delete cascade,
  acao       text not null check (acao in ('aprovado','ajuste','comentario')),
  comentario text,
  autor      text,
  origem     text default 'cliente',        -- cliente | agencia
  created_at timestamptz default now()
);

create index if not exists posts_mes_idx on posts(mes_id, ordem);
create index if not exists aprovacoes_post_idx on aprovacoes(post_id, created_at);

-- ---------- RLS ----------
-- Regra: usuário logado (você/admin) faz tudo. Anônimo (cliente) só entra pelas funções abaixo.
alter table clientes   enable row level security;
alter table meses      enable row level security;
alter table posts      enable row level security;
alter table destaques  enable row level security;
alter table aprovacoes enable row level security;

do $$ declare t text; begin
  foreach t in array array['clientes','meses','posts','destaques','aprovacoes'] loop
    execute format('drop policy if exists admin_all on %I', t);
    execute format('create policy admin_all on %I for all to authenticated using (true) with check (true)', t);
  end loop;
end $$;

-- ---------- storage ----------
insert into storage.buckets (id, name, public) values ('midia','midia', true)
  on conflict (id) do nothing;
drop policy if exists midia_public_read on storage.objects;
create policy midia_public_read on storage.objects for select using (bucket_id = 'midia');
drop policy if exists midia_admin_write on storage.objects;
create policy midia_admin_write on storage.objects for all to authenticated
  using (bucket_id = 'midia') with check (bucket_id = 'midia');

-- ---------- funções para o link do cliente (chamadas com a chave anon) ----------

-- Retorna tudo que a página precisa, só se o token bater e o mês estiver publicado.
create or replace function get_mes(p_token text, p_ano_mes text default null)
returns jsonb language plpgsql security definer set search_path = vistto as $$
declare c clientes; m meses; result jsonb;
begin
  select * into c from clientes where token = p_token;
  if c.id is null then return null; end if;

  select * into m from meses
   where cliente_id = c.id and publicado
     and (p_ano_mes is null or ano_mes = p_ano_mes)
   order by ano_mes desc limit 1;
  if m.id is null then return jsonb_build_object('cliente', jsonb_build_object('nome', c.nome), 'mes', null); end if;

  select jsonb_build_object(
    'cliente', jsonb_build_object('nome', c.nome, 'handle', c.handle, 'bio', c.bio, 'avatar_url', c.avatar_url),
    'mes', jsonb_build_object('id', m.id, 'ano_mes', m.ano_mes, 'titulo', m.titulo, 'intro', m.intro),
    'meses', (select coalesce(jsonb_agg(jsonb_build_object('ano_mes', ano_mes, 'titulo', titulo) order by ano_mes desc), '[]')
                from meses where cliente_id = c.id and publicado),
    'destaques', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'capa_url', capa_url) order by ordem), '[]')
                    from destaques where cliente_id = c.id),
    'posts', (select coalesce(jsonb_agg(jsonb_build_object(
                'id', p.id, 'ordem', p.ordem, 'numero', p.numero, 'data', p.data, 'tema', p.tema,
                'titulo', p.titulo, 'tipo', p.tipo, 'legenda', p.legenda, 'slides', p.slides,
                'video_url', p.video_url, 'capa_url', p.capa_url, 'status', p.status,
                'historico', (select coalesce(jsonb_agg(jsonb_build_object(
                                'acao', a.acao, 'comentario', a.comentario, 'autor', a.autor,
                                'origem', a.origem, 'created_at', a.created_at) order by a.created_at), '[]')
                              from aprovacoes a where a.post_id = p.id)
              ) order by p.ordem), '[]') from posts p where p.mes_id = m.id)
  ) into result;
  return result;
end $$;

-- Cliente aprova / pede ajuste / comenta. Valida o token contra o post.
create or replace function registrar_aprovacao(p_token text, p_post_id uuid, p_acao text, p_comentario text default null, p_autor text default null)
returns jsonb language plpgsql security definer set search_path = vistto as $$
declare ok boolean;
begin
  select exists (
    select 1 from posts p join meses m on m.id = p.mes_id join clientes c on c.id = m.cliente_id
     where p.id = p_post_id and c.token = p_token and m.publicado
  ) into ok;
  if not ok then raise exception 'token inválido'; end if;
  if p_acao not in ('aprovado','ajuste','comentario') then raise exception 'ação inválida'; end if;
  if p_acao = 'ajuste' and coalesce(trim(p_comentario),'') = '' then raise exception 'descreva o ajuste'; end if;

  insert into aprovacoes (post_id, acao, comentario, autor, origem)
    values (p_post_id, p_acao, nullif(trim(p_comentario),''), nullif(trim(p_autor),''), 'cliente');
  if p_acao in ('aprovado','ajuste') then
    update posts set status = p_acao where id = p_post_id;
  end if;
  return jsonb_build_object('ok', true, 'status', (select status from posts where id = p_post_id));
end $$;

grant execute on function get_mes(text, text) to anon, authenticated;
grant execute on function registrar_aprovacao(text, uuid, text, text, text) to anon, authenticated;

-- ---------- opcional: avisar você quando o cliente responder ----------
-- Supabase › Database › Webhooks › Create: table aprovacoes, event INSERT,
-- URL do seu cenário no Make/Zapier/n8n → manda WhatsApp/e-mail.

-- Executar uma vez, depois do schema original. Migração transacional, sem excluir conteúdo.
create table vistto.agencias(id uuid primary key default gen_random_uuid(),slug text unique not null,nome text not null);
insert into vistto.agencias(id,slug,nome) values
 ('10000000-0000-4000-8000-000000000002','forno','Forno Lab');
create table vistto.administradores(usuario_id uuid primary key references auth.users(id) on delete cascade);
create table vistto.agencia_usuarios(agencia_id uuid references vistto.agencias(id) on delete cascade,usuario_id uuid references auth.users(id) on delete cascade,primary key(agencia_id,usuario_id));
alter table vistto.agencias enable row level security;
alter table vistto.administradores enable row level security;
alter table vistto.agencia_usuarios enable row level security;
revoke all on vistto.agencias,vistto.administradores,vistto.agencia_usuarios from anon,authenticated;
grant select on vistto.agencias,vistto.agencia_usuarios to authenticated;
alter table vistto.clientes add column agencia_id uuid not null default '10000000-0000-4000-8000-000000000002' references vistto.agencias(id);
alter table vistto.clientes alter column agencia_id drop default;
alter table vistto.clientes drop constraint clientes_slug_key;
alter table vistto.clientes add unique(agencia_id,slug);
alter table vistto.clientes alter column token set default encode(extensions.gen_random_bytes(32),'hex');
create index on vistto.clientes(agencia_id);
create index on vistto.agencia_usuarios(usuario_id);
create function vistto.e_admin() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.administradores where usuario_id=auth.uid());
$$;
create function vistto.pode_agencia(a uuid) returns boolean language sql stable security definer set search_path='' as $$
 select vistto.e_admin() or exists(select 1 from vistto.agencia_usuarios where agencia_id=a and usuario_id=auth.uid());
$$;
revoke all on function vistto.e_admin(),vistto.pode_agencia(uuid) from public;
grant execute on function vistto.e_admin(),vistto.pode_agencia(uuid) to authenticated;
create policy agencia_leitura on vistto.agencias for select to authenticated using(vistto.pode_agencia(id));
create policy membros_leitura on vistto.agencia_usuarios for select to authenticated using(vistto.e_admin() or usuario_id=auth.uid());
do $$ declare t text; begin
 foreach t in array array['clientes','meses','posts','destaques','aprovacoes'] loop
   execute format('drop policy if exists admin_all on vistto.%I',t);
   execute format('revoke all on vistto.%I from anon,authenticated',t);
   execute format('grant select,insert,update,delete on vistto.%I to authenticated',t);
 end loop;
end $$;
create policy clientes_agencia on vistto.clientes for all to authenticated using(vistto.pode_agencia(agencia_id)) with check(vistto.pode_agencia(agencia_id));
create policy meses_agencia on vistto.meses for all to authenticated using(exists(select 1 from vistto.clientes c where c.id=cliente_id)) with check(exists(select 1 from vistto.clientes c where c.id=cliente_id));
create policy posts_agencia on vistto.posts for all to authenticated using(exists(select 1 from vistto.meses m where m.id=mes_id)) with check(exists(select 1 from vistto.meses m where m.id=mes_id));
create policy destaques_agencia on vistto.destaques for all to authenticated using(exists(select 1 from vistto.clientes c where c.id=cliente_id)) with check(exists(select 1 from vistto.clientes c where c.id=cliente_id));
create policy aprovacoes_agencia on vistto.aprovacoes for select to authenticated using(exists(select 1 from vistto.posts p where p.id=post_id));
revoke insert,update,delete on vistto.aprovacoes from authenticated;

create function vistto.meu_contexto() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('superadmin',vistto.e_admin(),'agencias',coalesce((select jsonb_agg(to_jsonb(a) order by a.nome) from vistto.agencias a where vistto.pode_agencia(a.id)),'[]'::jsonb));
$$;
create function vistto.listar_acessos(p_agencia uuid) returns jsonb language plpgsql security definer set search_path='' as $$
begin
 if not vistto.e_admin() then raise exception 'Acesso negado';end if;
 return coalesce((select jsonb_agg(jsonb_build_object('usuario_id',u.id,'email',u.email)) from vistto.agencia_usuarios m join auth.users u on u.id=m.usuario_id where m.agencia_id=p_agencia),'[]'::jsonb);
end $$;
create function vistto.autorizar_acesso(p_agencia uuid,p_email text) returns void language plpgsql security definer set search_path='' as $$
declare u uuid; begin
 if not vistto.e_admin() then raise exception 'Acesso negado';end if;
 select id into u from auth.users where lower(email)=lower(trim(p_email)) and email_confirmed_at is not null;
 if u is null then raise exception 'A pessoa precisa criar o acesso e confirmar o e-mail primeiro.';end if;
 insert into vistto.agencia_usuarios values(p_agencia,u) on conflict do nothing;
end $$;
create function vistto.revogar_acesso(p_agencia uuid,p_usuario uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if not vistto.e_admin() then raise exception 'Acesso negado';end if;
 delete from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=p_usuario;
end $$;
create function vistto.renovar_link(p_cliente uuid) returns text language plpgsql security definer set search_path='vistto' as $$
declare t text; begin
 if not exists(select 1 from clientes where id=p_cliente and pode_agencia(agencia_id)) then raise exception 'Acesso negado';end if;
 t:=encode(extensions.gen_random_bytes(32),'hex'); update clientes set token=t where id=p_cliente;return t;
end $$;
create function vistto.marcar_ajustado(p_post uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from vistto.posts p join vistto.meses m on m.id=p.mes_id join vistto.clientes c on c.id=m.cliente_id where p.id=p_post and vistto.pode_agencia(c.agencia_id)) then raise exception 'Acesso negado';end if;
 update vistto.posts set status='pendente' where id=p_post;
 insert into vistto.aprovacoes(post_id,acao,comentario,autor,origem) values(p_post,'comentario','Ajuste aplicado. Nova versão disponível para aprovação.','Agência','agencia');
end $$;
revoke all on function vistto.meu_contexto(),vistto.listar_acessos(uuid),vistto.autorizar_acesso(uuid,text),vistto.revogar_acesso(uuid,uuid),vistto.renovar_link(uuid),vistto.marcar_ajustado(uuid) from public;
grant execute on function vistto.meu_contexto(),vistto.listar_acessos(uuid),vistto.autorizar_acesso(uuid,text),vistto.revogar_acesso(uuid,uuid),vistto.renovar_link(uuid),vistto.marcar_ajustado(uuid) to authenticated;

-- Cada objeto privado pertence à agência que o enviou. Referências antigas são preservadas.
create function vistto.midia_path(v text) returns text language sql immutable set search_path='' as $$
 select case when v like 'midia:%' then substr(v,7) when v like 'https://vbiebfcbzproffkrkluy.supabase.co/storage/v1/object/public/midia/%' then split_part(v,'/storage/v1/object/public/midia/',2) else null end;
$$;
create table vistto.midia_legada(path text primary key,agencia_id uuid not null references vistto.agencias(id));
alter table vistto.midia_legada enable row level security;
revoke all on vistto.midia_legada from anon,authenticated;
insert into vistto.midia_legada select name,'10000000-0000-4000-8000-000000000002'::uuid from storage.objects where bucket_id='midia';
create function vistto.midia_da_agencia(v text,a uuid) returns boolean language sql stable security definer set search_path='' as $$
 select v is null or v='' or split_part(vistto.midia_path(v),'/',1)=a::text or exists(select 1 from vistto.midia_legada l where l.path=vistto.midia_path(v) and l.agencia_id=a);
$$;
create function vistto.validar_midia() returns trigger language plpgsql security definer set search_path='' as $$
declare a uuid;v text; vals text[];begin
 if tg_table_name='clientes' then
  a:=new.agencia_id; vals:=array[new.avatar_url];
  if tg_op='UPDATE' and old.agencia_id<>new.agencia_id then raise exception 'Não é permitido transferir clientes entre agências';end if;
 elsif tg_table_name='destaques' then
  select agencia_id into a from vistto.clientes where id=new.cliente_id;vals:=array[new.capa_url];
 else
  select c.agencia_id into a from vistto.clientes c join vistto.meses m on c.id=m.cliente_id where m.id=new.mes_id;
  if jsonb_typeof(new.slides)<>'array' then raise exception 'Slides inválidos';end if;
  vals:=array[new.capa_url,new.video_url]||array(select jsonb_array_elements_text(new.slides));
 end if;
 foreach v in array vals loop
  if not vistto.midia_da_agencia(v,a) then
   -- Uma edição de texto pode preservar uma referência externa já existente.
   if tg_op='UPDATE' and (to_jsonb(old)=to_jsonb(new) or
     (tg_table_name='clientes' and to_jsonb(old)->'avatar_url'=to_jsonb(new)->'avatar_url') or
     (tg_table_name='destaques' and to_jsonb(old)->'capa_url'=to_jsonb(new)->'capa_url') or
     (tg_table_name='posts' and to_jsonb(old)->'slides'=to_jsonb(new)->'slides' and to_jsonb(old)->'video_url'=to_jsonb(new)->'video_url' and to_jsonb(old)->'capa_url'=to_jsonb(new)->'capa_url')) then continue;end if;
   raise exception 'Envie a mídia pelo painel desta agência.';
  end if;
 end loop; return new;
end $$;
create trigger validar_cliente before insert or update on vistto.clientes for each row execute function vistto.validar_midia();
create trigger validar_destaque before insert or update on vistto.destaques for each row execute function vistto.validar_midia();
create trigger validar_post before insert or update on vistto.posts for each row execute function vistto.validar_midia();
create function vistto.pode_midia(n text) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.agencias a where vistto.pode_agencia(a.id) and (split_part(n,'/',1)=a.id::text or exists(select 1 from vistto.midia_legada l where l.path=n and l.agencia_id=a.id)));
$$;
revoke all on function vistto.midia_da_agencia(text,uuid),vistto.validar_midia(),vistto.pode_midia(text) from public;
grant execute on function vistto.pode_midia(text) to authenticated;
drop policy if exists midia_public_read on storage.objects;
drop policy if exists midia_admin_write on storage.objects;
update storage.buckets set public=false where id='midia';
create policy midia_agencia_read on storage.objects for select to authenticated using(bucket_id='midia' and vistto.pode_midia(name));
create policy midia_agencia_insert on storage.objects for insert to authenticated with check(bucket_id='midia' and exists(select 1 from vistto.agencias a where split_part(name,'/',1)=a.id::text and vistto.pode_agencia(a.id)));
-- Sem sobrescrita: uma revisão sempre cria um novo arquivo e mantém o histórico.

-- get_mes e registrar_aprovacao são substituídas abaixo pela versão compatível.

create or replace function get_mes(p_token text, p_ano_mes text default null)
returns jsonb language plpgsql security definer set search_path = vistto as $$
declare c clientes; m meses; result jsonb;
begin
  select * into c from clientes where token = p_token;
  if c.id is null then return null; end if;

  select * into m from meses
   where cliente_id = c.id and publicado
     and (p_ano_mes is null or ano_mes = p_ano_mes)
   order by ano_mes desc limit 1;
  if m.id is null then return jsonb_build_object('cliente', jsonb_build_object('nome', c.nome), 'mes', null, 'agencia', (select to_jsonb(a) from agencias a where a.id=c.agencia_id)); end if;

  select jsonb_build_object(
    'agencia', (select to_jsonb(a) from agencias a where a.id=c.agencia_id),
    'cliente', jsonb_build_object('nome', c.nome, 'handle', c.handle, 'bio', c.bio, 'avatar_url', c.avatar_url),
    'mes', jsonb_build_object('id', m.id, 'ano_mes', m.ano_mes, 'titulo', m.titulo, 'intro', m.intro),
    'meses', (select coalesce(jsonb_agg(jsonb_build_object('ano_mes', ano_mes, 'titulo', titulo) order by ano_mes desc), '[]')
                from meses where cliente_id = c.id and publicado),
    'destaques', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'capa_url', capa_url) order by ordem), '[]')
                    from destaques where cliente_id = c.id),
    'posts', (select coalesce(jsonb_agg(jsonb_build_object(
                'id', p.id, 'ordem', p.ordem, 'numero', p.numero, 'data', p.data, 'tema', p.tema,
                'titulo', p.titulo, 'tipo', p.tipo, 'legenda', p.legenda, 'slides', p.slides,
                'video_url', p.video_url, 'capa_url', p.capa_url, 'status', p.status,
                'historico', (select coalesce(jsonb_agg(jsonb_build_object(
                                'acao', a.acao, 'comentario', a.comentario, 'autor', a.autor,
                                'origem', a.origem, 'created_at', a.created_at) order by a.created_at), '[]')
                              from aprovacoes a where a.post_id = p.id)
              ) order by p.ordem), '[]') from posts p where p.mes_id = m.id)
  ) into result;
  return result;
end $$;

-- Cliente aprova / pede ajuste / comenta. Valida o token contra o post.
create or replace function registrar_aprovacao(p_token text, p_post_id uuid, p_acao text, p_comentario text default null, p_autor text default null)
returns jsonb language plpgsql security definer set search_path = vistto as $$
declare ok boolean;
begin
  select exists (
    select 1 from posts p join meses m on m.id = p.mes_id join clientes c on c.id = m.cliente_id
     where p.id = p_post_id and c.token = p_token and m.publicado
  ) into ok;
  if not ok then raise exception 'token inválido'; end if;
  if p_acao not in ('aprovado','ajuste','comentario') then raise exception 'ação inválida'; end if;
  if p_acao in ('ajuste','comentario') and coalesce(trim(p_comentario),'') = '' then raise exception 'descreva o ajuste'; end if;

  if length(p_comentario)>10000 or length(p_autor)>150 then raise exception 'Texto muito longo'; end if;
  insert into aprovacoes (post_id, acao, comentario, autor, origem)
    values (p_post_id, p_acao, nullif(trim(p_comentario),''), nullif(trim(p_autor),''), 'cliente');
  if p_acao in ('aprovado','ajuste') then
    update posts set status = p_acao where id = p_post_id;
  end if;
  return jsonb_build_object('ok', true, 'status', (select status from posts where id = p_post_id));
end $$;

grant execute on function get_mes(text, text) to anon, authenticated;
grant execute on function registrar_aprovacao(text, uuid, text, text, text) to anon, authenticated;


revoke all on function get_mes(text,text) from public,anon,authenticated;
revoke all on function registrar_aprovacao(text,uuid,text,text,text) from public;
grant execute on function get_mes(text,text) to service_role;
grant execute on function registrar_aprovacao(text,uuid,text,text,text) to anon,authenticated;

-- ---------- hierarquia ----------

alter table vistto.agencia_usuarios
  add column papel text not null default 'designer'
    check (papel in ('dono','socio','head','designer','editor_video','social_media','gestor_trafego')),
  add column nome text check (char_length(nome) <= 80),
  add column criado_por uuid references auth.users(id) on delete set null,
  add column created_at timestamptz not null default now();
alter table vistto.agencia_usuarios alter column papel drop default;

create function vistto.nivel_papel(p text) returns int language sql immutable set search_path='' as $$
 select case p when 'dono' then 3 when 'socio' then 3 when 'head' then 2
   when 'designer' then 1 when 'editor_video' then 1 when 'social_media' then 1 when 'gestor_trafego' then 1 else 0 end;
$$;
create function vistto.meu_nivel(a uuid) returns int language sql stable security definer set search_path='' as $$
 select case when vistto.e_admin() then 4 else coalesce((
   select vistto.nivel_papel(m.papel) from vistto.agencia_usuarios m where m.agencia_id=a and m.usuario_id=auth.uid()),0) end;
$$;
create function vistto.pode_gerir(a uuid) returns boolean language sql stable security definer set search_path='' as $$
 select vistto.meu_nivel(a) >= 2;
$$;
create function vistto.agencia_do_cliente(c uuid) returns uuid language sql stable security definer set search_path='' as $$
 select agencia_id from vistto.clientes where id=c;
$$;
create function vistto.agencia_do_mes(m uuid) returns uuid language sql stable security definer set search_path='' as $$
 select c.agencia_id from vistto.meses x join vistto.clientes c on c.id=x.cliente_id where x.id=m;
$$;
revoke all on function vistto.nivel_papel(text),vistto.meu_nivel(uuid),vistto.pode_gerir(uuid),vistto.agencia_do_cliente(uuid),vistto.agencia_do_mes(uuid) from public;
grant execute on function vistto.nivel_papel(text),vistto.meu_nivel(uuid),vistto.pode_gerir(uuid),vistto.agencia_do_cliente(uuid),vistto.agencia_do_mes(uuid) to authenticated;

-- Clientes: toda a agência vê; só Head+ cria, edita ou exclui. O token do link fica oculto para a equipe.
drop policy clientes_agencia on vistto.clientes;
create policy clientes_ler on vistto.clientes for select to authenticated using (vistto.pode_agencia(agencia_id));
create policy clientes_criar on vistto.clientes for insert to authenticated with check (vistto.pode_gerir(agencia_id));
create policy clientes_editar on vistto.clientes for update to authenticated using (vistto.pode_gerir(agencia_id)) with check (vistto.pode_gerir(agencia_id));
create policy clientes_excluir on vistto.clientes for delete to authenticated using (vistto.pode_gerir(agencia_id));
revoke select on vistto.clientes from authenticated;
grant select (id,agencia_id,slug,nome,handle,bio,avatar_url,created_at) on vistto.clientes to authenticated;

-- Destaques fazem parte do cadastro do cliente.
drop policy destaques_agencia on vistto.destaques;
create policy destaques_ler on vistto.destaques for select to authenticated using (exists(select 1 from vistto.clientes c where c.id=cliente_id));
create policy destaques_criar on vistto.destaques for insert to authenticated with check (vistto.pode_gerir(vistto.agencia_do_cliente(cliente_id)));
create policy destaques_editar on vistto.destaques for update to authenticated using (vistto.pode_gerir(vistto.agencia_do_cliente(cliente_id))) with check (vistto.pode_gerir(vistto.agencia_do_cliente(cliente_id)));
create policy destaques_excluir on vistto.destaques for delete to authenticated using (vistto.pode_gerir(vistto.agencia_do_cliente(cliente_id)));

-- Meses: a equipe cria e edita; publicar e excluir é Head+.
drop policy meses_agencia on vistto.meses;
create policy meses_ler on vistto.meses for select to authenticated using (exists(select 1 from vistto.clientes c where c.id=cliente_id));
create policy meses_criar on vistto.meses for insert to authenticated with check (exists(select 1 from vistto.clientes c where c.id=cliente_id));
create policy meses_editar on vistto.meses for update to authenticated using (exists(select 1 from vistto.clientes c where c.id=cliente_id)) with check (exists(select 1 from vistto.clientes c where c.id=cliente_id));
create policy meses_excluir on vistto.meses for delete to authenticated using (vistto.pode_gerir(vistto.agencia_do_cliente(cliente_id)));
create function vistto.proteger_publicacao() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then return new; end if;
 if (tg_op='INSERT' and new.publicado) or (tg_op='UPDATE' and new.publicado is distinct from old.publicado) then
   if not vistto.pode_gerir(vistto.agencia_do_cliente(new.cliente_id)) then raise exception 'Somente Head, sócios e donos publicam o mês.'; end if;
 end if;
 return new;
end $$;
create trigger proteger_publicacao before insert or update on vistto.meses for each row execute function vistto.proteger_publicacao();

-- Posts: a equipe cria, edita e reordena; excluir é Head+. O status só muda pela resposta do cliente ou por "marcar como ajustado".
drop policy posts_agencia on vistto.posts;
create policy posts_ler on vistto.posts for select to authenticated using (exists(select 1 from vistto.meses m where m.id=mes_id));
create policy posts_criar on vistto.posts for insert to authenticated with check (exists(select 1 from vistto.meses m where m.id=mes_id));
create policy posts_editar on vistto.posts for update to authenticated using (exists(select 1 from vistto.meses m where m.id=mes_id)) with check (exists(select 1 from vistto.meses m where m.id=mes_id));
create policy posts_excluir on vistto.posts for delete to authenticated using (vistto.pode_gerir(vistto.agencia_do_mes(mes_id)));
create function vistto.proteger_status() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or current_setting('vistto.status_ok',true)='1' then return new; end if;
 if (tg_op='INSERT' and new.status<>'pendente') or (tg_op='UPDATE' and new.status is distinct from old.status) then
   raise exception 'O status muda só pela resposta do cliente.';
 end if;
 return new;
end $$;
create trigger proteger_status before insert or update on vistto.posts for each row execute function vistto.proteger_status();

-- Links do cliente: só Head+.
create or replace function vistto.renovar_link(p_cliente uuid) returns text language plpgsql security definer set search_path='vistto' as $$
declare t text; begin
 if not vistto.pode_gerir(vistto.agencia_do_cliente(p_cliente)) then raise exception 'Acesso negado'; end if;
 t:=encode(extensions.gen_random_bytes(32),'hex'); update clientes set token=t where id=p_cliente; return t;
end $$;
create function vistto.link_cliente(p_cliente uuid) returns text language plpgsql stable security definer set search_path='' as $$
begin
 if not vistto.pode_gerir(vistto.agencia_do_cliente(p_cliente)) then raise exception 'Acesso negado'; end if;
 return (select token from vistto.clientes where id=p_cliente);
end $$;

create or replace function vistto.marcar_ajustado(p_post uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from vistto.posts p join vistto.meses m on m.id=p.mes_id join vistto.clientes c on c.id=m.cliente_id where p.id=p_post and vistto.pode_agencia(c.agencia_id)) then raise exception 'Acesso negado'; end if;
 perform set_config('vistto.status_ok','1',true);
 update vistto.posts set status='pendente' where id=p_post;
 perform set_config('vistto.status_ok','',true);
 insert into vistto.aprovacoes(post_id,acao,comentario,autor,origem) values(p_post,'comentario','Ajuste aplicado. Nova versão disponível para aprovação.','Agência','agencia');
end $$;

create or replace function vistto.registrar_aprovacao(p_token text, p_post_id uuid, p_acao text, p_comentario text default null, p_autor text default null)
returns jsonb language plpgsql security definer set search_path = vistto as $$
declare ok boolean;
begin
  select exists (
    select 1 from posts p join meses m on m.id = p.mes_id join clientes c on c.id = m.cliente_id
     where p.id = p_post_id and c.token = p_token and m.publicado
  ) into ok;
  if not ok then raise exception 'token inválido'; end if;
  if p_acao not in ('aprovado','ajuste','comentario') then raise exception 'ação inválida'; end if;
  if p_acao in ('ajuste','comentario') and coalesce(trim(p_comentario),'') = '' then raise exception 'descreva o ajuste'; end if;
  if length(p_comentario)>10000 or length(p_autor)>150 then raise exception 'Texto muito longo'; end if;
  insert into aprovacoes (post_id, acao, comentario, autor, origem)
    values (p_post_id, p_acao, nullif(trim(p_comentario),''), nullif(trim(p_autor),''), 'cliente');
  if p_acao in ('aprovado','ajuste') then
    perform set_config('vistto.status_ok','1',true);
    update posts set status = p_acao where id = p_post_id;
    perform set_config('vistto.status_ok','',true);
  end if;
  return jsonb_build_object('ok', true, 'status', (select status from posts where id = p_post_id));
end $$;

-- Contexto e gestão de acessos.
create or replace function vistto.meu_contexto() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('superadmin',vistto.e_admin(),'agencias',coalesce((
   select jsonb_agg(jsonb_build_object('id',a.id,'slug',a.slug,'nome',a.nome,
     'papel',case when vistto.e_admin() then 'admin' else (select m.papel from vistto.agencia_usuarios m where m.agencia_id=a.id and m.usuario_id=auth.uid()) end,
     'nivel',vistto.meu_nivel(a.id)) order by a.nome)
   from vistto.agencias a where vistto.pode_agencia(a.id)),'[]'::jsonb));
$$;

drop function vistto.listar_acessos(uuid);
create function vistto.listar_acessos(p_agencia uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia);
begin
 if n < 2 then raise exception 'Acesso negado'; end if;
 return coalesce((select jsonb_agg(jsonb_build_object('usuario_id',u.id,'email',u.email,'nome',m.nome,'papel',m.papel,
     'pode_gerir',vistto.nivel_papel(m.papel) < n) order by vistto.nivel_papel(m.papel) desc, u.email)
   from vistto.agencia_usuarios m join auth.users u on u.id=m.usuario_id where m.agencia_id=p_agencia),'[]'::jsonb);
end $$;

drop function vistto.autorizar_acesso(uuid,text);
create function vistto.autorizar_acesso(p_agencia uuid,p_email text,p_papel text,p_nome text default null) returns void language plpgsql security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia); u uuid; atual text;
begin
 if n < 2 or vistto.nivel_papel(p_papel) = 0 or vistto.nivel_papel(p_papel) >= n then raise exception 'Você não pode atribuir esse papel.'; end if;
 select id into u from auth.users where lower(email)=lower(trim(p_email)) and email_confirmed_at is not null;
 if u is null or exists(select 1 from vistto.administradores where usuario_id=u) then raise exception 'Não foi possível autorizar este e-mail.'; end if;
 select papel into atual from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=u;
 if atual is not null and vistto.nivel_papel(atual) >= n then raise exception 'Não foi possível autorizar este e-mail.'; end if;
 if atual is null and not vistto.e_admin() and exists(select 1 from vistto.agencia_usuarios where usuario_id=u) then
   raise exception 'Não foi possível autorizar este e-mail.';
 end if;
 insert into vistto.agencia_usuarios(agencia_id,usuario_id,papel,nome,criado_por) values(p_agencia,u,p_papel,nullif(trim(p_nome),''),auth.uid())
 on conflict (agencia_id,usuario_id) do update set papel=excluded.papel, nome=coalesce(excluded.nome,vistto.agencia_usuarios.nome);
end $$;

create or replace function vistto.revogar_acesso(p_agencia uuid,p_usuario uuid) returns void language plpgsql security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia); atual text;
begin
 select papel into atual from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=p_usuario;
 if n < 2 or atual is null or vistto.nivel_papel(atual) >= n then raise exception 'Acesso negado'; end if;
 delete from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=p_usuario;
end $$;

create function vistto.alterar_papel(p_agencia uuid,p_usuario uuid,p_papel text) returns void language plpgsql security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia); atual text;
begin
 select papel into atual from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=p_usuario;
 if n < 2 or atual is null or vistto.nivel_papel(atual) >= n or vistto.nivel_papel(p_papel) = 0 or vistto.nivel_papel(p_papel) >= n then
   raise exception 'Você não pode atribuir esse papel.';
 end if;
 update vistto.agencia_usuarios set papel=p_papel where agencia_id=p_agencia and usuario_id=p_usuario;
end $$;

revoke all on function vistto.proteger_publicacao(),vistto.proteger_status() from public,anon,authenticated;
revoke execute on function vistto.nivel_papel(text),vistto.meu_nivel(uuid),vistto.pode_gerir(uuid),vistto.agencia_do_cliente(uuid),vistto.agencia_do_mes(uuid) from anon;
revoke all on function vistto.link_cliente(uuid),vistto.listar_acessos(uuid),vistto.autorizar_acesso(uuid,text,text,text),vistto.alterar_papel(uuid,uuid,text),vistto.meu_contexto(),vistto.revogar_acesso(uuid,uuid),vistto.renovar_link(uuid),vistto.marcar_ajustado(uuid) from public,anon;
grant execute on function vistto.link_cliente(uuid),vistto.listar_acessos(uuid),vistto.autorizar_acesso(uuid,text,text,text),vistto.alterar_papel(uuid,uuid,text),vistto.meu_contexto(),vistto.revogar_acesso(uuid,uuid),vistto.renovar_link(uuid),vistto.marcar_ajustado(uuid) to authenticated;
revoke all on function vistto.registrar_aprovacao(text,uuid,text,text,text) from public;
grant execute on function vistto.registrar_aprovacao(text,uuid,text,text,text) to anon,authenticated;

-- ---------- squads ----------

create table vistto.squads(
  id uuid primary key default gen_random_uuid(),
  agencia_id uuid not null references vistto.agencias(id) on delete cascade,
  nome text not null check (char_length(trim(nome)) between 1 and 80),
  created_at timestamptz not null default now(),
  unique (agencia_id, nome)
);
create table vistto.squad_membros(
  squad_id uuid not null references vistto.squads(id) on delete cascade,
  usuario_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (squad_id, usuario_id)
);
create index on vistto.squad_membros(usuario_id);
alter table vistto.squads enable row level security;
alter table vistto.squad_membros enable row level security;
revoke all on vistto.squads, vistto.squad_membros from anon, authenticated;
grant select on vistto.squads to authenticated;

alter table vistto.clientes add column squad_id uuid references vistto.squads(id) on delete set null;
create index on vistto.clientes(squad_id);
grant select (squad_id) on vistto.clientes to authenticated;

create function vistto.no_squad(s uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.squad_membros where squad_id=s and usuario_id=auth.uid());
$$;
create function vistto.pode_ver(a uuid, s uuid) returns boolean language sql stable security definer set search_path='' as $$
 select vistto.meu_nivel(a) >= 3 or (vistto.meu_nivel(a) >= 1 and s is not null and vistto.no_squad(s));
$$;
create function vistto.pode_gerir_em(a uuid, s uuid) returns boolean language sql stable security definer set search_path='' as $$
 select vistto.meu_nivel(a) >= 3 or (vistto.meu_nivel(a) = 2 and s is not null and vistto.no_squad(s));
$$;
create function vistto.pode_ver_cliente(c uuid) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce((select vistto.pode_ver(agencia_id, squad_id) from vistto.clientes where id=c), false);
$$;
create function vistto.pode_gerir_cliente(c uuid) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce((select vistto.pode_gerir_em(agencia_id, squad_id) from vistto.clientes where id=c), false);
$$;
revoke all on function vistto.no_squad(uuid),vistto.pode_ver(uuid,uuid),vistto.pode_gerir_em(uuid,uuid),vistto.pode_ver_cliente(uuid),vistto.pode_gerir_cliente(uuid) from public, anon;
grant execute on function vistto.no_squad(uuid),vistto.pode_ver(uuid,uuid),vistto.pode_gerir_em(uuid,uuid),vistto.pode_ver_cliente(uuid),vistto.pode_gerir_cliente(uuid) to authenticated;

create policy squads_ler on vistto.squads for select to authenticated using (vistto.pode_ver(agencia_id, id));

-- O squad do cliente precisa ser da mesma agência.
create function vistto.validar_squad_cliente() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.squad_id is not null and not exists(select 1 from vistto.squads where id=new.squad_id and agencia_id=new.agencia_id) then
   raise exception 'Squad inválido para esta agência.';
 end if;
 return new;
end $$;
create trigger validar_squad_cliente before insert or update on vistto.clientes for each row execute function vistto.validar_squad_cliente();

-- Membro de squad precisa pertencer à agência; ao sair da agência, sai dos squads dela.
create function vistto.validar_membro_squad() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from vistto.squads s join vistto.agencia_usuarios m on m.agencia_id=s.agencia_id where s.id=new.squad_id and m.usuario_id=new.usuario_id) then
   raise exception 'A pessoa precisa fazer parte da agência antes de entrar no squad.';
 end if;
 return new;
end $$;
create trigger validar_membro_squad before insert or update on vistto.squad_membros for each row execute function vistto.validar_membro_squad();
create function vistto.limpar_squads() returns trigger language plpgsql security definer set search_path='' as $$
begin
 delete from vistto.squad_membros sm using vistto.squads s where s.id=sm.squad_id and s.agencia_id=old.agencia_id and sm.usuario_id=old.usuario_id;
 return old;
end $$;
create trigger limpar_squads after delete on vistto.agencia_usuarios for each row execute function vistto.limpar_squads();
revoke all on function vistto.validar_squad_cliente(),vistto.validar_membro_squad(),vistto.limpar_squads() from public, anon, authenticated;

-- Clientes por squad.
drop policy clientes_ler on vistto.clientes;
drop policy clientes_criar on vistto.clientes;
drop policy clientes_editar on vistto.clientes;
drop policy clientes_excluir on vistto.clientes;
create policy clientes_ler on vistto.clientes for select to authenticated using (vistto.pode_ver(agencia_id, squad_id));
create policy clientes_criar on vistto.clientes for insert to authenticated with check (vistto.pode_gerir_em(agencia_id, squad_id));
create policy clientes_editar on vistto.clientes for update to authenticated using (vistto.pode_gerir_em(agencia_id, squad_id)) with check (vistto.pode_gerir_em(agencia_id, squad_id));
create policy clientes_excluir on vistto.clientes for delete to authenticated using (vistto.pode_gerir_em(agencia_id, squad_id));

drop policy destaques_criar on vistto.destaques;
drop policy destaques_editar on vistto.destaques;
drop policy destaques_excluir on vistto.destaques;
create policy destaques_criar on vistto.destaques for insert to authenticated with check (vistto.pode_gerir_cliente(cliente_id));
create policy destaques_editar on vistto.destaques for update to authenticated using (vistto.pode_gerir_cliente(cliente_id)) with check (vistto.pode_gerir_cliente(cliente_id));
create policy destaques_excluir on vistto.destaques for delete to authenticated using (vistto.pode_gerir_cliente(cliente_id));
drop policy meses_excluir on vistto.meses;
create policy meses_excluir on vistto.meses for delete to authenticated using (vistto.pode_gerir_cliente(cliente_id));
drop policy posts_excluir on vistto.posts;
create policy posts_excluir on vistto.posts for delete to authenticated using (vistto.pode_gerir_cliente((select m.cliente_id from vistto.meses m where m.id=mes_id)));

create or replace function vistto.proteger_publicacao() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then return new; end if;
 if (tg_op='INSERT' and new.publicado) or (tg_op='UPDATE' and new.publicado is distinct from old.publicado) then
   if not vistto.pode_gerir_cliente(new.cliente_id) then raise exception 'Somente Head do squad, sócios e donos publicam o mês.'; end if;
 end if;
 return new;
end $$;
create or replace function vistto.renovar_link(p_cliente uuid) returns text language plpgsql security definer set search_path='vistto' as $$
declare t text; begin
 if not vistto.pode_gerir_cliente(p_cliente) then raise exception 'Acesso negado'; end if;
 t:=encode(extensions.gen_random_bytes(32),'hex'); update clientes set token=t where id=p_cliente; return t;
end $$;
create or replace function vistto.link_cliente(p_cliente uuid) returns text language plpgsql stable security definer set search_path='' as $$
begin
 if not vistto.pode_gerir_cliente(p_cliente) then raise exception 'Acesso negado'; end if;
 return (select token from vistto.clientes where id=p_cliente);
end $$;
create or replace function vistto.marcar_ajustado(p_post uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if not exists(select 1 from vistto.posts p join vistto.meses m on m.id=p.mes_id where p.id=p_post and vistto.pode_ver_cliente(m.cliente_id)) then raise exception 'Acesso negado'; end if;
 perform set_config('vistto.status_ok','1',true);
 update vistto.posts set status='pendente' where id=p_post;
 perform set_config('vistto.status_ok','',true);
 insert into vistto.aprovacoes(post_id,acao,comentario,autor,origem) values(p_post,'comentario','Ajuste aplicado. Nova versão disponível para aprovação.','Agência','agencia');
end $$;

-- Mídia: dono/sócio veem a agência inteira; os demais, só arquivos que enviaram ou que estão em clientes que enxergam.
create or replace function vistto.pode_midia(n text) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.agencias a where (split_part(n,'/',1)=a.id::text or exists(select 1 from vistto.midia_legada l where l.path=n and l.agencia_id=a.id))
   and (vistto.meu_nivel(a.id) >= 3 or (vistto.meu_nivel(a.id) >= 1 and (
     exists(select 1 from vistto.posts p join vistto.meses m on m.id=p.mes_id join vistto.clientes c on c.id=m.cliente_id
            where c.agencia_id=a.id and vistto.pode_ver(c.agencia_id,c.squad_id)
              and (('midia:'||n) in (p.capa_url,p.video_url) or p.slides ? ('midia:'||n)))
     or exists(select 1 from vistto.clientes c where c.agencia_id=a.id and c.avatar_url=('midia:'||n) and vistto.pode_ver(c.agencia_id,c.squad_id))
     or exists(select 1 from vistto.destaques d join vistto.clientes c on c.id=d.cliente_id where c.agencia_id=a.id and d.capa_url=('midia:'||n) and vistto.pode_ver(c.agencia_id,c.squad_id))
   ))));
$$;
drop policy midia_agencia_read on storage.objects;
create policy midia_agencia_read on storage.objects for select to authenticated using (bucket_id='midia' and (owner_id = auth.uid()::text or vistto.pode_midia(name)));

-- Acessos com squads.
create function vistto.divide_squad(a uuid, u uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.squad_membros x join vistto.squad_membros y on y.squad_id=x.squad_id join vistto.squads s on s.id=x.squad_id
   where s.agencia_id=a and x.usuario_id=auth.uid() and y.usuario_id=u);
$$;
create function vistto.pode_gerir_pessoa(a uuid, u uuid) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce((select vistto.nivel_papel(m.papel) < vistto.meu_nivel(a)
     and (vistto.meu_nivel(a) >= 3 or (vistto.meu_nivel(a) = 2 and vistto.divide_squad(a,u)))
   from vistto.agencia_usuarios m where m.agencia_id=a and m.usuario_id=u), false);
$$;
revoke all on function vistto.divide_squad(uuid,uuid),vistto.pode_gerir_pessoa(uuid,uuid) from public, anon;
grant execute on function vistto.divide_squad(uuid,uuid),vistto.pode_gerir_pessoa(uuid,uuid) to authenticated;

create or replace function vistto.listar_acessos(p_agencia uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia);
begin
 if n < 2 then raise exception 'Acesso negado'; end if;
 return coalesce((select jsonb_agg(jsonb_build_object('usuario_id',u.id,'email',u.email,'nome',m.nome,'papel',m.papel,
     'pode_gerir',vistto.pode_gerir_pessoa(p_agencia,u.id),
     'squads',coalesce((select jsonb_agg(jsonb_build_object('id',s.id,'nome',s.nome) order by s.nome) from vistto.squad_membros sm join vistto.squads s on s.id=sm.squad_id where sm.usuario_id=u.id and s.agencia_id=p_agencia and vistto.pode_ver(p_agencia,s.id)),'[]'::jsonb))
     order by vistto.nivel_papel(m.papel) desc, coalesce(m.nome,u.email))
   from vistto.agencia_usuarios m join auth.users u on u.id=m.usuario_id
   where m.agencia_id=p_agencia and (n >= 3 or u.id=auth.uid() or vistto.divide_squad(p_agencia,u.id))),'[]'::jsonb);
end $$;

drop function vistto.autorizar_acesso(uuid,text,text,text);
create function vistto.autorizar_acesso(p_agencia uuid,p_email text,p_papel text,p_nome text default null,p_squad uuid default null) returns void language plpgsql security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia); u uuid; atual text;
begin
 if n < 2 or vistto.nivel_papel(p_papel) = 0 or vistto.nivel_papel(p_papel) >= n then raise exception 'Você não pode atribuir esse papel.'; end if;
 if p_squad is not null and not exists(select 1 from vistto.squads where id=p_squad and agencia_id=p_agencia) then raise exception 'Squad inválido.'; end if;
 if n = 2 and (p_squad is null or not vistto.no_squad(p_squad)) then raise exception 'Escolha um dos seus squads.'; end if;
 select id into u from auth.users where lower(email)=lower(trim(p_email)) and email_confirmed_at is not null;
 if u is null or exists(select 1 from vistto.administradores where usuario_id=u) then raise exception 'Não foi possível autorizar este e-mail.'; end if;
 select papel into atual from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=u;
 if atual is not null and not vistto.pode_gerir_pessoa(p_agencia,u) and not (n=2 and vistto.nivel_papel(atual)<2) then raise exception 'Não foi possível autorizar este e-mail.'; end if;
 if atual is null and not vistto.e_admin() and exists(select 1 from vistto.agencia_usuarios where usuario_id=u) then
   raise exception 'Não foi possível autorizar este e-mail.';
 end if;
 insert into vistto.agencia_usuarios(agencia_id,usuario_id,papel,nome,criado_por) values(p_agencia,u,p_papel,nullif(trim(p_nome),''),auth.uid())
 on conflict (agencia_id,usuario_id) do update set papel=case when n>=3 or vistto.pode_gerir_pessoa(p_agencia,u) then excluded.papel else vistto.agencia_usuarios.papel end,
   nome=coalesce(excluded.nome,vistto.agencia_usuarios.nome);
 if p_squad is not null then insert into vistto.squad_membros(squad_id,usuario_id) values(p_squad,u) on conflict do nothing; end if;
end $$;

create or replace function vistto.revogar_acesso(p_agencia uuid,p_usuario uuid) returns void language plpgsql security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia);
begin
 if n < 2 or not vistto.pode_gerir_pessoa(p_agencia,p_usuario) then raise exception 'Acesso negado'; end if;
 if n >= 3 then
   delete from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=p_usuario;
 else
   -- Head tira a pessoa só dos squads dele; sem squad nenhum, ela sai da agência.
   delete from vistto.squad_membros sm using vistto.squads s where s.id=sm.squad_id and s.agencia_id=p_agencia and sm.usuario_id=p_usuario and vistto.no_squad(sm.squad_id);
   if not exists(select 1 from vistto.squad_membros sm join vistto.squads s on s.id=sm.squad_id where s.agencia_id=p_agencia and sm.usuario_id=p_usuario) then
     delete from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=p_usuario;
   end if;
 end if;
end $$;

create or replace function vistto.alterar_papel(p_agencia uuid,p_usuario uuid,p_papel text) returns void language plpgsql security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia);
begin
 if n < 2 or not vistto.pode_gerir_pessoa(p_agencia,p_usuario) or vistto.nivel_papel(p_papel) = 0 or vistto.nivel_papel(p_papel) >= n then
   raise exception 'Você não pode atribuir esse papel.';
 end if;
 update vistto.agencia_usuarios set papel=p_papel where agencia_id=p_agencia and usuario_id=p_usuario;
end $$;

create function vistto.listar_squads(p_agencia uuid) returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(jsonb_build_object('id',s.id,'nome',s.nome,
   'clientes',(select count(*) from vistto.clientes c where c.squad_id=s.id),
   'membros',coalesce((select jsonb_agg(jsonb_build_object('usuario_id',m.usuario_id,'nome',coalesce(m.nome,u.email),'papel',m.papel) order by vistto.nivel_papel(m.papel) desc, coalesce(m.nome,u.email))
      from vistto.squad_membros sm join vistto.agencia_usuarios m on m.usuario_id=sm.usuario_id and m.agencia_id=s.agencia_id join auth.users u on u.id=sm.usuario_id where sm.squad_id=s.id),'[]'::jsonb))
   order by s.nome),'[]'::jsonb)
 from vistto.squads s where s.agencia_id=p_agencia and vistto.meu_nivel(p_agencia) >= 1 and vistto.pode_ver(p_agencia,s.id);
$$;
create function vistto.salvar_squad(p_agencia uuid,p_nome text,p_id uuid default null) returns uuid language plpgsql security definer set search_path='' as $$
declare r uuid;
begin
 if vistto.meu_nivel(p_agencia) < 3 then raise exception 'Somente donos e sócios organizam os squads.'; end if;
 if p_id is null then
   insert into vistto.squads(agencia_id,nome) values(p_agencia,trim(p_nome)) returning id into r;
 else
   update vistto.squads set nome=trim(p_nome) where id=p_id and agencia_id=p_agencia returning id into r;
   if r is null then raise exception 'Squad não encontrado.'; end if;
 end if;
 return r;
end $$;
create function vistto.excluir_squad(p_squad uuid) returns void language plpgsql security definer set search_path='' as $$
declare a uuid;
begin
 select agencia_id into a from vistto.squads where id=p_squad;
 if a is null or vistto.meu_nivel(a) < 3 then raise exception 'Somente donos e sócios organizam os squads.'; end if;
 delete from vistto.squads where id=p_squad;
end $$;
create function vistto.definir_membro_squad(p_squad uuid,p_usuario uuid,p_dentro boolean) returns void language plpgsql security definer set search_path='' as $$
declare a uuid;
begin
 select agencia_id into a from vistto.squads where id=p_squad;
 if a is null or vistto.meu_nivel(a) < 3 then raise exception 'Somente donos e sócios organizam os squads.'; end if;
 if not exists(select 1 from vistto.agencia_usuarios where agencia_id=a and usuario_id=p_usuario) then raise exception 'Pessoa fora da agência.'; end if;
 if p_dentro then insert into vistto.squad_membros(squad_id,usuario_id) values(p_squad,p_usuario) on conflict do nothing;
 else delete from vistto.squad_membros where squad_id=p_squad and usuario_id=p_usuario; end if;
end $$;

revoke all on function vistto.listar_acessos(uuid),vistto.autorizar_acesso(uuid,text,text,text,uuid),vistto.revogar_acesso(uuid,uuid),vistto.alterar_papel(uuid,uuid,text),vistto.listar_squads(uuid),vistto.salvar_squad(uuid,text,uuid),vistto.excluir_squad(uuid),vistto.definir_membro_squad(uuid,uuid,boolean),vistto.renovar_link(uuid),vistto.link_cliente(uuid),vistto.marcar_ajustado(uuid),vistto.pode_midia(text) from public, anon;
grant execute on function vistto.listar_acessos(uuid),vistto.autorizar_acesso(uuid,text,text,text,uuid),vistto.revogar_acesso(uuid,uuid),vistto.alterar_papel(uuid,uuid,text),vistto.listar_squads(uuid),vistto.salvar_squad(uuid,text,uuid),vistto.excluir_squad(uuid),vistto.definir_membro_squad(uuid,uuid,boolean),vistto.renovar_link(uuid),vistto.link_cliente(uuid),vistto.marcar_ajustado(uuid),vistto.pode_midia(text) to authenticated;

-- ---------- convites ----------
create table vistto.convites(
  usuario_id uuid primary key references auth.users(id) on delete cascade,
  codigo_hash text not null,
  expira_em timestamptz not null,
  tentativas int not null default 0,
  criado_por uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table vistto.convites enable row level security;
revoke all on vistto.convites from anon, authenticated;

create function vistto.convite_por_email(p_email text) returns table(usuario_id uuid, codigo_hash text, expira_em timestamptz, tentativas int)
language sql stable security definer set search_path='' as $$
 select c.usuario_id, c.codigo_hash, c.expira_em, c.tentativas
 from vistto.convites c join auth.users u on u.id=c.usuario_id
 where lower(u.email)=lower(trim(p_email));
$$;
revoke all on function vistto.convite_por_email(text) from public, anon, authenticated;
grant execute on function vistto.convite_por_email(text) to service_role;

create or replace function vistto.listar_acessos(p_agencia uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia);
begin
 if n < 2 then raise exception 'Acesso negado'; end if;
 return coalesce((select jsonb_agg(jsonb_build_object('usuario_id',u.id,'email',u.email,'nome',m.nome,'papel',m.papel,
     'pode_gerir',vistto.pode_gerir_pessoa(p_agencia,u.id),
     'pendente',exists(select 1 from vistto.convites c where c.usuario_id=u.id),
     'squads',coalesce((select jsonb_agg(jsonb_build_object('id',s.id,'nome',s.nome) order by s.nome) from vistto.squad_membros sm join vistto.squads s on s.id=sm.squad_id where sm.usuario_id=u.id and s.agencia_id=p_agencia and vistto.pode_ver(p_agencia,s.id)),'[]'::jsonb))
     order by vistto.nivel_papel(m.papel) desc, coalesce(m.nome,u.email))
   from vistto.agencia_usuarios m join auth.users u on u.id=m.usuario_id
   where m.agencia_id=p_agencia and (n >= 3 or u.id=auth.uid() or vistto.divide_squad(p_agencia,u.id))),'[]'::jsonb);
end $$;
revoke all on function vistto.listar_acessos(uuid) from public, anon;
grant execute on function vistto.listar_acessos(uuid) to authenticated;

-- ---------- squads opcionais ----------
alter table vistto.agencias add column usa_squads boolean not null default false;
-- ative squads por agência com: update vistto.agencias set usa_squads = true where id = '...';

create function vistto.usa_squads(a uuid) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce((select usa_squads from vistto.agencias where id=a), false);
$$;
revoke all on function vistto.usa_squads(uuid) from public, anon;
grant execute on function vistto.usa_squads(uuid) to authenticated;

create or replace function vistto.pode_ver(a uuid, s uuid) returns boolean language sql stable security definer set search_path='' as $$
 select vistto.meu_nivel(a) >= 3 or (vistto.meu_nivel(a) >= 1 and (not vistto.usa_squads(a) or (s is not null and vistto.no_squad(s))));
$$;
create or replace function vistto.pode_gerir_em(a uuid, s uuid) returns boolean language sql stable security definer set search_path='' as $$
 select vistto.meu_nivel(a) >= 3 or (vistto.meu_nivel(a) = 2 and (not vistto.usa_squads(a) or (s is not null and vistto.no_squad(s))));
$$;
create or replace function vistto.pode_gerir_pessoa(a uuid, u uuid) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce((select vistto.nivel_papel(m.papel) < vistto.meu_nivel(a)
     and (vistto.meu_nivel(a) >= 3 or (vistto.meu_nivel(a) = 2 and (not vistto.usa_squads(a) or vistto.divide_squad(a,u))))
   from vistto.agencia_usuarios m where m.agencia_id=a and m.usuario_id=u), false);
$$;

create or replace function vistto.meu_contexto() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object('superadmin',vistto.e_admin(),'agencias',coalesce((
   select jsonb_agg(jsonb_build_object('id',a.id,'slug',a.slug,'nome',a.nome,'usa_squads',a.usa_squads,
     'papel',case when vistto.e_admin() then 'admin' else (select m.papel from vistto.agencia_usuarios m where m.agencia_id=a.id and m.usuario_id=auth.uid()) end,
     'nivel',vistto.meu_nivel(a.id)) order by a.nome)
   from vistto.agencias a where vistto.pode_agencia(a.id)),'[]'::jsonb));
$$;

create or replace function vistto.listar_acessos(p_agencia uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia); todos boolean := n >= 3 or not vistto.usa_squads(p_agencia);
begin
 if n < 2 then raise exception 'Acesso negado'; end if;
 return coalesce((select jsonb_agg(jsonb_build_object('usuario_id',u.id,'email',u.email,'nome',m.nome,'papel',m.papel,
     'pode_gerir',vistto.pode_gerir_pessoa(p_agencia,u.id),
     'pendente',exists(select 1 from vistto.convites c where c.usuario_id=u.id),
     'squads',coalesce((select jsonb_agg(jsonb_build_object('id',s.id,'nome',s.nome) order by s.nome) from vistto.squad_membros sm join vistto.squads s on s.id=sm.squad_id where sm.usuario_id=u.id and s.agencia_id=p_agencia and vistto.pode_ver(p_agencia,s.id)),'[]'::jsonb))
     order by vistto.nivel_papel(m.papel) desc, coalesce(m.nome,u.email))
   from vistto.agencia_usuarios m join auth.users u on u.id=m.usuario_id
   where m.agencia_id=p_agencia and (todos or u.id=auth.uid() or vistto.divide_squad(p_agencia,u.id))),'[]'::jsonb);
end $$;

create or replace function vistto.autorizar_acesso(p_agencia uuid,p_email text,p_papel text,p_nome text default null,p_squad uuid default null) returns void language plpgsql security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia); u uuid; atual text; sq boolean := vistto.usa_squads(p_agencia);
begin
 if n < 2 or vistto.nivel_papel(p_papel) = 0 or vistto.nivel_papel(p_papel) >= n then raise exception 'Você não pode atribuir esse papel.'; end if;
 if p_squad is not null and (not sq or not exists(select 1 from vistto.squads where id=p_squad and agencia_id=p_agencia)) then raise exception 'Squad inválido.'; end if;
 if n = 2 and sq and (p_squad is null or not vistto.no_squad(p_squad)) then raise exception 'Escolha um dos seus squads.'; end if;
 select id into u from auth.users where lower(email)=lower(trim(p_email)) and email_confirmed_at is not null;
 if u is null or exists(select 1 from vistto.administradores where usuario_id=u) then raise exception 'Não foi possível autorizar este e-mail.'; end if;
 select papel into atual from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=u;
 if atual is not null and not vistto.pode_gerir_pessoa(p_agencia,u) and not (n=2 and vistto.nivel_papel(atual)<2) then raise exception 'Não foi possível autorizar este e-mail.'; end if;
 if atual is null and not vistto.e_admin() and exists(select 1 from vistto.agencia_usuarios where usuario_id=u) then
   raise exception 'Não foi possível autorizar este e-mail.';
 end if;
 insert into vistto.agencia_usuarios(agencia_id,usuario_id,papel,nome,criado_por) values(p_agencia,u,p_papel,nullif(trim(p_nome),''),auth.uid())
 on conflict (agencia_id,usuario_id) do update set papel=case when n>=3 or vistto.pode_gerir_pessoa(p_agencia,u) then excluded.papel else vistto.agencia_usuarios.papel end,
   nome=coalesce(excluded.nome,vistto.agencia_usuarios.nome);
 if p_squad is not null then insert into vistto.squad_membros(squad_id,usuario_id) values(p_squad,u) on conflict do nothing; end if;
end $$;

create or replace function vistto.revogar_acesso(p_agencia uuid,p_usuario uuid) returns void language plpgsql security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia);
begin
 if n < 2 or not vistto.pode_gerir_pessoa(p_agencia,p_usuario) then raise exception 'Acesso negado'; end if;
 if n >= 3 or not vistto.usa_squads(p_agencia) then
   delete from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=p_usuario;
 else
   delete from vistto.squad_membros sm using vistto.squads s where s.id=sm.squad_id and s.agencia_id=p_agencia and sm.usuario_id=p_usuario and vistto.no_squad(sm.squad_id);
   if not exists(select 1 from vistto.squad_membros sm join vistto.squads s on s.id=sm.squad_id where s.agencia_id=p_agencia and sm.usuario_id=p_usuario) then
     delete from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=p_usuario;
   end if;
 end if;
end $$;

create or replace function vistto.salvar_squad(p_agencia uuid,p_nome text,p_id uuid default null) returns uuid language plpgsql security definer set search_path='' as $$
declare r uuid;
begin
 if vistto.meu_nivel(p_agencia) < 3 then raise exception 'Somente donos e sócios organizam os squads.'; end if;
 if not vistto.usa_squads(p_agencia) then raise exception 'Esta agência não trabalha com squads.'; end if;
 if p_id is null then
   insert into vistto.squads(agencia_id,nome) values(p_agencia,trim(p_nome)) returning id into r;
 else
   update vistto.squads set nome=trim(p_nome) where id=p_id and agencia_id=p_agencia returning id into r;
   if r is null then raise exception 'Squad não encontrado.'; end if;
 end if;
 return r;
end $$;

revoke all on function vistto.meu_contexto(),vistto.listar_acessos(uuid),vistto.autorizar_acesso(uuid,text,text,text,uuid),vistto.revogar_acesso(uuid,uuid),vistto.salvar_squad(uuid,text,uuid),vistto.pode_ver(uuid,uuid),vistto.pode_gerir_em(uuid,uuid),vistto.pode_gerir_pessoa(uuid,uuid) from public, anon;
grant execute on function vistto.meu_contexto(),vistto.listar_acessos(uuid),vistto.autorizar_acesso(uuid,text,text,text,uuid),vistto.revogar_acesso(uuid,uuid),vistto.salvar_squad(uuid,text,uuid),vistto.pode_ver(uuid,uuid),vistto.pode_gerir_em(uuid,uuid),vistto.pode_gerir_pessoa(uuid,uuid) to authenticated;
-- ---------- clientes por gestor de tráfego ----------
create table vistto.cliente_gestores(
  cliente_id uuid not null references vistto.clientes(id) on delete cascade,
  usuario_id uuid not null references auth.users(id) on delete cascade,
  criado_por uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  primary key (cliente_id, usuario_id)
);
create index on vistto.cliente_gestores(usuario_id);
alter table vistto.cliente_gestores enable row level security;
revoke all on vistto.cliente_gestores from anon, authenticated;

-- Regras de leitura
create function vistto.so_atribuidos(a uuid) returns boolean language sql stable security definer set search_path='' as $$
 select not vistto.e_admin() and exists(select 1 from vistto.agencia_usuarios where agencia_id=a and usuario_id=auth.uid() and papel='gestor_trafego');
$$;
create function vistto.cuida_cliente(c uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.cliente_gestores where cliente_id=c and usuario_id=auth.uid());
$$;
create function vistto.pode_ver_c(a uuid, s uuid, c uuid) returns boolean language sql stable security definer set search_path='' as $$
 select case when vistto.so_atribuidos(a) then vistto.cuida_cliente(c) else vistto.pode_ver(a,s) end;
$$;
create function vistto.gestor_elegivel(c uuid, u uuid) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.clientes x join vistto.agencia_usuarios m on m.agencia_id=x.agencia_id and m.usuario_id=u and m.papel='gestor_trafego'
   where x.id=c and (not vistto.usa_squads(x.agencia_id)
     or (x.squad_id is not null and exists(select 1 from vistto.squad_membros sm where sm.squad_id=x.squad_id and sm.usuario_id=u))));
$$;

create or replace function vistto.pode_ver_cliente(c uuid) returns boolean language sql stable security definer set search_path='' as $$
 select coalesce((select vistto.pode_ver_c(agencia_id, squad_id, id) from vistto.clientes where id=c), false);
$$;
drop policy clientes_ler on vistto.clientes;
create policy clientes_ler on vistto.clientes for select to authenticated using (vistto.pode_ver_c(agencia_id, squad_id, id));

create or replace function vistto.pode_midia(n text) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.agencias a where (split_part(n,'/',1)=a.id::text or exists(select 1 from vistto.midia_legada l where l.path=n and l.agencia_id=a.id))
   and (vistto.meu_nivel(a.id) >= 3 or (vistto.meu_nivel(a.id) >= 1 and (
     exists(select 1 from vistto.posts p join vistto.meses m on m.id=p.mes_id join vistto.clientes c on c.id=m.cliente_id
            where c.agencia_id=a.id and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id)
              and (('midia:'||n) in (p.capa_url,p.video_url) or p.slides ? ('midia:'||n)))
     or exists(select 1 from vistto.clientes c where c.agencia_id=a.id and c.avatar_url=('midia:'||n) and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id))
     or exists(select 1 from vistto.destaques d join vistto.clientes c on c.id=d.cliente_id where c.agencia_id=a.id and d.capa_url=('midia:'||n) and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id))
   ))));
$$;

-- Integridade: só gestor de tráfego elegível; saiu do squad, da agência ou do papel, perde os clientes.
create function vistto.validar_cliente_gestor() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if not vistto.gestor_elegivel(new.cliente_id, new.usuario_id) then
   raise exception 'O gestor precisa ser de tráfego e estar no squad deste cliente.';
 end if;
 return new;
end $$;
create trigger validar_cliente_gestor before insert or update on vistto.cliente_gestores for each row execute function vistto.validar_cliente_gestor();

create function vistto.limpar_gestor_squad() returns trigger language plpgsql security definer set search_path='' as $$
begin
 delete from vistto.cliente_gestores g using vistto.clientes x where x.id=g.cliente_id and x.squad_id=old.squad_id and g.usuario_id=old.usuario_id;
 return old;
end $$;
create trigger limpar_gestor_squad after delete on vistto.squad_membros for each row execute function vistto.limpar_gestor_squad();

create function vistto.limpar_gestor_agencia() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='DELETE' or new.papel <> 'gestor_trafego' then
   delete from vistto.cliente_gestores g using vistto.clientes x where x.id=g.cliente_id and x.agencia_id=old.agencia_id and g.usuario_id=old.usuario_id;
 end if;
 return null;
end $$;
create trigger limpar_gestor_agencia after delete or update of papel on vistto.agencia_usuarios for each row execute function vistto.limpar_gestor_agencia();

create function vistto.limpar_gestor_cliente() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.squad_id is distinct from old.squad_id then
   delete from vistto.cliente_gestores g where g.cliente_id=new.id and not vistto.gestor_elegivel(new.id, g.usuario_id);
 end if;
 return new;
end $$;
create trigger limpar_gestor_cliente after update of squad_id on vistto.clientes for each row execute function vistto.limpar_gestor_cliente();

-- Painel: Head (nos próprios squads), sócios e donos escolhem os clientes de cada gestor.
create function vistto.clientes_do_gestor(p_agencia uuid, p_usuario uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$
begin
 if vistto.meu_nivel(p_agencia) < 2 or not vistto.pode_gerir_pessoa(p_agencia, p_usuario)
    or not exists(select 1 from vistto.agencia_usuarios where agencia_id=p_agencia and usuario_id=p_usuario and papel='gestor_trafego') then
   raise exception 'Acesso negado';
 end if;
 return coalesce((select jsonb_agg(jsonb_build_object('id',c.id,'nome',c.nome,'squad',s.nome,
     'marcado',exists(select 1 from vistto.cliente_gestores g where g.cliente_id=c.id and g.usuario_id=p_usuario))
     order by s.nome nulls first, c.nome)
   from vistto.clientes c left join vistto.squads s on s.id=c.squad_id
   where c.agencia_id=p_agencia and vistto.pode_gerir_cliente(c.id) and vistto.gestor_elegivel(c.id, p_usuario)),'[]'::jsonb);
end $$;

create function vistto.definir_gestor_cliente(p_cliente uuid, p_usuario uuid, p_dentro boolean) returns void language plpgsql security definer set search_path='' as $$
declare a uuid := vistto.agencia_do_cliente(p_cliente);
begin
 if a is null or not vistto.pode_gerir_cliente(p_cliente) or not vistto.pode_gerir_pessoa(a, p_usuario) then raise exception 'Acesso negado'; end if;
 if p_dentro then
   insert into vistto.cliente_gestores(cliente_id, usuario_id, criado_por) values(p_cliente, p_usuario, auth.uid()) on conflict do nothing;
 else
   delete from vistto.cliente_gestores where cliente_id=p_cliente and usuario_id=p_usuario;
 end if;
end $$;

create or replace function vistto.listar_acessos(p_agencia uuid) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare n int := vistto.meu_nivel(p_agencia); todos boolean := n >= 3 or not vistto.usa_squads(p_agencia);
begin
 if n < 2 then raise exception 'Acesso negado'; end if;
 return coalesce((select jsonb_agg(jsonb_build_object('usuario_id',u.id,'email',u.email,'nome',m.nome,'papel',m.papel,
     'pode_gerir',vistto.pode_gerir_pessoa(p_agencia,u.id),
     'pendente',exists(select 1 from vistto.convites c where c.usuario_id=u.id),
     'clientes',case when m.papel='gestor_trafego' then (select count(*) from vistto.cliente_gestores g join vistto.clientes c on c.id=g.cliente_id
        where g.usuario_id=u.id and c.agencia_id=p_agencia and vistto.pode_ver_c(p_agencia,c.squad_id,c.id)) end,
     'squads',coalesce((select jsonb_agg(jsonb_build_object('id',s.id,'nome',s.nome) order by s.nome) from vistto.squad_membros sm join vistto.squads s on s.id=sm.squad_id where sm.usuario_id=u.id and s.agencia_id=p_agencia and vistto.pode_ver(p_agencia,s.id)),'[]'::jsonb))
     order by vistto.nivel_papel(m.papel) desc, coalesce(m.nome,u.email))
   from vistto.agencia_usuarios m join auth.users u on u.id=m.usuario_id
   where m.agencia_id=p_agencia and (todos or u.id=auth.uid() or vistto.divide_squad(p_agencia,u.id))),'[]'::jsonb);
end $$;

revoke all on function vistto.validar_cliente_gestor(),vistto.limpar_gestor_squad(),vistto.limpar_gestor_agencia(),vistto.limpar_gestor_cliente() from public, anon, authenticated;
revoke all on function vistto.so_atribuidos(uuid),vistto.cuida_cliente(uuid),vistto.pode_ver_c(uuid,uuid,uuid),vistto.gestor_elegivel(uuid,uuid),vistto.pode_ver_cliente(uuid),vistto.pode_midia(text),vistto.clientes_do_gestor(uuid,uuid),vistto.definir_gestor_cliente(uuid,uuid,boolean),vistto.listar_acessos(uuid) from public, anon;
grant execute on function vistto.so_atribuidos(uuid),vistto.cuida_cliente(uuid),vistto.pode_ver_c(uuid,uuid,uuid),vistto.gestor_elegivel(uuid,uuid),vistto.pode_ver_cliente(uuid),vistto.pode_midia(text),vistto.clientes_do_gestor(uuid,uuid),vistto.definir_gestor_cliente(uuid,uuid,boolean),vistto.listar_acessos(uuid) to authenticated;

-- ---------- espaço e limpeza ----------
alter table vistto.meses add column arquivado_em timestamptz;

-- Todo caminho de mídia citado em algum lugar do sistema.
create function vistto.midia_refs() returns table(path text) language sql stable security definer set search_path='' as $$
 select vistto.midia_path(v) from (
   select jsonb_array_elements_text(slides) v from vistto.posts
   union all select capa_url from vistto.posts
   union all select video_url from vistto.posts
   union all select avatar_url from vistto.clientes
   union all select capa_url from vistto.destaques
 ) x where v is not null and v <> '' and vistto.midia_path(v) is not null and vistto.midia_path(v) <> '';
$$;

-- Quanto a agência ocupa, quanto é lixo e quantos meses já passaram do prazo.
create function vistto.uso_armazenamento(p_agencia uuid, p_dias int default 90) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare r jsonb;
begin
 if vistto.meu_nivel(p_agencia) < 3 then raise exception 'Acesso negado'; end if;
 select jsonb_build_object(
   'arquivos', count(*), 'bytes', coalesce(sum(tam),0),
   'orfaos', count(*) filter (where orfao), 'bytes_orfaos', coalesce(sum(tam) filter (where orfao),0),
   'bytes_bucket', (select coalesce(sum(coalesce((metadata->>'size')::bigint,0)),0) from storage.objects where bucket_id='midia'),
   'meses_antigos', (select count(*) from vistto.meses m join vistto.clientes c on c.id=m.cliente_id
      where c.agencia_id=p_agencia and m.arquivado_em is null and m.created_at < now() - make_interval(days => greatest(p_dias,1)))
 ) into r
 from (
   select coalesce((o.metadata->>'size')::bigint,0) tam,
     not exists(select 1 from vistto.midia_refs() f where f.path=o.name)
     and not exists(select 1 from vistto.midia_legada l where l.path=o.name) orfao
   from storage.objects o
   where o.bucket_id='midia' and split_part(o.name,'/',1)=p_agencia::text
 ) t;
 return r;
end $$;

-- O que pode sair do servidor: arquivos sem dono e meses vencidos, com os caminhos de cada um.
create function vistto.plano_limpeza(p_agencia uuid, p_dias int default 90) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare r jsonb;
begin
 if vistto.meu_nivel(p_agencia) < 3 then raise exception 'Acesso negado'; end if;
 select jsonb_build_object(
   'orfaos', coalesce((select jsonb_agg(o.name) from storage.objects o
      where o.bucket_id='midia' and split_part(o.name,'/',1)=p_agencia::text
        and not exists(select 1 from vistto.midia_refs() f where f.path=o.name)
        and not exists(select 1 from vistto.midia_legada l where l.path=o.name)),'[]'::jsonb),
   'meses', coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'titulo',m.titulo,'cliente',c.nome,'criado_em',m.created_at,
        'arquivos', coalesce((select jsonb_agg(vistto.midia_path(v)) from (
            select jsonb_array_elements_text(p.slides) v from vistto.posts p where p.mes_id=m.id
            union all select p.capa_url from vistto.posts p where p.mes_id=m.id
            union all select p.video_url from vistto.posts p where p.mes_id=m.id
          ) y where v is not null and v <> '' and vistto.midia_path(v) <> ''),'[]'::jsonb))
      order by m.created_at)
      from vistto.meses m join vistto.clientes c on c.id=m.cliente_id
      where c.agencia_id=p_agencia and m.arquivado_em is null and m.created_at < now() - make_interval(days => greatest(p_dias,1))),'[]'::jsonb)
 ) into r;
 return r;
end $$;

-- Arquiva o mês: limpa as referências de mídia dos posts e fecha o link do cliente.
create function vistto.arquivar_mes(p_mes uuid) returns void language plpgsql security definer set search_path='' as $$
declare c uuid;
begin
 select cliente_id into c from vistto.meses where id=p_mes;
 if c is null or vistto.meu_nivel((select agencia_id from vistto.clientes where id=c)) < 3 then raise exception 'Acesso negado'; end if;
 update vistto.posts set slides='[]'::jsonb, capa_url=null, video_url=null where mes_id=p_mes;
 update vistto.meses set publicado=false, arquivado_em=now() where id=p_mes;
end $$;

revoke all on function vistto.midia_refs(),vistto.uso_armazenamento(uuid,int),vistto.plano_limpeza(uuid,int),vistto.arquivar_mes(uuid) from public, anon;
grant execute on function vistto.uso_armazenamento(uuid,int),vistto.plano_limpeza(uuid,int),vistto.arquivar_mes(uuid) to authenticated;

-- ---------- mídias no Cloudflare R2 ----------
-- Agora o caminho também sai de uma referência do R2.
create or replace function vistto.midia_path(v text) returns text language sql immutable set search_path='' as $$
 select case
   when v like 'midia:%' then substr(v,7)
   when v like 'r2:%' then substr(v,4)
   when v like 'https://vbiebfcbzproffkrkluy.supabase.co/storage/v1/object/public/midia/%' then split_part(v,'/storage/v1/object/public/midia/',2)
   else null end;
$$;

-- Quem pode ver este arquivo do R2: dono e sócio veem a agência inteira; os demais, só o que aparece
-- em cliente que eles enxergam (mesma regra da mídia do Storage, incluindo squad e gestor de tráfego).
create function vistto.pode_ref(v text) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.agencias a
   where vistto.midia_path(v) is not null and split_part(vistto.midia_path(v),'/',1)=a.id::text
     and (vistto.meu_nivel(a.id) >= 3 or (vistto.meu_nivel(a.id) >= 1 and (
       exists(select 1 from vistto.posts p join vistto.meses m on m.id=p.mes_id join vistto.clientes c on c.id=m.cliente_id
              where c.agencia_id=a.id and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id)
                and (v in (p.capa_url,p.video_url) or p.slides ? v))
       or exists(select 1 from vistto.clientes c where c.agencia_id=a.id and c.avatar_url=v and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id))
       or exists(select 1 from vistto.destaques d join vistto.clientes c on c.id=d.cliente_id
              where c.agencia_id=a.id and d.capa_url=v and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id))
     ))));
$$;

-- Quem pode enviar arte nesta agência: qualquer pessoa da equipe.
create function vistto.pode_enviar(p_agencia uuid) returns boolean language sql stable security definer set search_path='' as $$
 select vistto.meu_nivel(p_agencia) >= 1;
$$;

-- Espaço e limpeza passam a ser só do administrador geral: a conta mostra o total do servidor,
-- e um dono de agência não deve nem saber que existe outra agência ali.
create or replace function vistto.uso_armazenamento(p_agencia uuid, p_dias int default 90) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare r jsonb;
begin
 if not vistto.e_admin() then raise exception 'Acesso negado'; end if;
 select jsonb_build_object(
   'arquivos', count(*), 'bytes', coalesce(sum(tam),0),
   'orfaos', count(*) filter (where orfao), 'bytes_orfaos', coalesce(sum(tam) filter (where orfao),0),
   'bytes_bucket', (select coalesce(sum(coalesce((metadata->>'size')::bigint,0)),0) from storage.objects where bucket_id='midia'),
   'meses_antigos', (select count(*) from vistto.meses m join vistto.clientes c on c.id=m.cliente_id
      where c.agencia_id=p_agencia and m.arquivado_em is null and m.created_at < now() - make_interval(days => greatest(p_dias,1)))
 ) into r
 from (
   select coalesce((o.metadata->>'size')::bigint,0) tam,
     not exists(select 1 from vistto.midia_refs() f where f.path=o.name)
     and not exists(select 1 from vistto.midia_legada l where l.path=o.name) orfao
   from storage.objects o
   where o.bucket_id='midia' and split_part(o.name,'/',1)=p_agencia::text
 ) t;
 return r;
end $$;

create or replace function vistto.arquivar_mes(p_mes uuid) returns void language plpgsql security definer set search_path='' as $$
declare c uuid;
begin
 select cliente_id into c from vistto.meses where id=p_mes;
 if c is null or not vistto.e_admin() then raise exception 'Acesso negado'; end if;
 update vistto.posts set slides='[]'::jsonb, capa_url=null, video_url=null where mes_id=p_mes;
 update vistto.meses set publicado=false, arquivado_em=now() where id=p_mes;
end $$;

-- O plano de limpeza passa a devolver a referência inteira, para saber de onde apagar cada arquivo.
create or replace function vistto.plano_limpeza(p_agencia uuid, p_dias int default 90) returns jsonb language plpgsql stable security definer set search_path='' as $$
declare r jsonb;
begin
 if not vistto.e_admin() then raise exception 'Acesso negado'; end if;
 select jsonb_build_object(
   'orfaos', coalesce((select jsonb_agg(o.name) from storage.objects o
      where o.bucket_id='midia' and split_part(o.name,'/',1)=p_agencia::text
        and not exists(select 1 from vistto.midia_refs() f where f.path=o.name)
        and not exists(select 1 from vistto.midia_legada l where l.path=o.name)),'[]'::jsonb),
   'meses', coalesce((select jsonb_agg(jsonb_build_object('id',m.id,'titulo',m.titulo,'cliente',c.nome,'criado_em',m.created_at,
        'arquivos', coalesce((select jsonb_agg(v) from (
            select jsonb_array_elements_text(p.slides) v from vistto.posts p where p.mes_id=m.id
            union all select p.capa_url from vistto.posts p where p.mes_id=m.id
            union all select p.video_url from vistto.posts p where p.mes_id=m.id
          ) y where v is not null and v <> '' and vistto.midia_path(v) is not null),'[]'::jsonb))
      order by m.created_at)
      from vistto.meses m join vistto.clientes c on c.id=m.cliente_id
      where c.agencia_id=p_agencia and m.arquivado_em is null and m.created_at < now() - make_interval(days => greatest(p_dias,1))),'[]'::jsonb)
 ) into r;
 return r;
end $$;

revoke all on function vistto.pode_ref(text),vistto.pode_enviar(uuid),vistto.midia_path(text),vistto.plano_limpeza(uuid,int),vistto.uso_armazenamento(uuid,int),vistto.arquivar_mes(uuid) from public, anon;
grant execute on function vistto.pode_ref(text),vistto.pode_enviar(uuid),vistto.midia_path(text),vistto.plano_limpeza(uuid,int),vistto.uso_armazenamento(uuid,int),vistto.arquivar_mes(uuid) to authenticated;

-- ---------- fechaduras extras ----------
alter table vistto.posts
  add constraint posts_numero_simples check (numero is null or numero ~ '^[[:alnum:] ._/-]{1,12}$') not valid,
  add constraint posts_data_curta check (data is null or char_length(data) <= 16) not valid;
alter table vistto.posts validate constraint posts_numero_simples;
alter table vistto.posts validate constraint posts_data_curta;

-- Conta a tentativa e devolve o convite na mesma operação: mil pedidos ao mesmo tempo não furam o limite.
create function vistto.tentar_convite(p_email text) returns table(usuario_id uuid, codigo_hash text)
language sql security definer set search_path='' as $$
 update vistto.convites c set tentativas = c.tentativas + 1
 from auth.users u
 where u.id = c.usuario_id and lower(u.email) = lower(trim(p_email))
   and c.tentativas < 5 and c.expira_em > now()
 returning c.usuario_id, c.codigo_hash;
$$;
revoke all on function vistto.tentar_convite(text) from public, anon, authenticated;
grant execute on function vistto.tentar_convite(text) to service_role;

-- Envio novo só pelo R2. A leitura das artes antigas continua igual.
drop policy if exists midia_agencia_insert on storage.objects;

-- ---------- inventário das artes no R2 ----------
-- Caminhos de arte que hoje moram no R2, por agência. Só o administrador geral.
create function vistto.refs_r2(p_agencia uuid) returns setof text language sql stable security definer set search_path='' as $$
 select distinct vistto.midia_path(v) from (
   select jsonb_array_elements_text(slides) v from vistto.posts
   union all select capa_url from vistto.posts
   union all select video_url from vistto.posts
   union all select avatar_url from vistto.clientes
   union all select capa_url from vistto.destaques
 ) x
 where vistto.e_admin() and v like 'r2:%' and vistto.midia_path(v) like p_agencia::text || '/%';
$$;
revoke all on function vistto.refs_r2(uuid) from public, anon;
grant execute on function vistto.refs_r2(uuid) to authenticated;

-- Vistto · anúncios: Meta Ads e Google Ads. Executar uma vez, depois de espaco-r2.sql. Não apaga conteúdo.
-- A entrega ganha um canal. 'instagram' é o que já existe (o mês do feed). 'meta' e 'google' são campanhas.
-- Campanha → conjunto (Meta) ou grupo de anúncios (Google) → anúncio, como nos gerenciadores.
-- Quem vê anúncio: gestor de tráfego, Head, sócio, dono e administrador geral. Designer e editor seguem só no feed.
-- O cliente aprova anúncio pelo mesmo link, em abas separadas.

-- ---------- 1. canal na entrega ----------
alter table vistto.meses
  add column canal text not null default 'instagram' check (canal in ('instagram','meta','google')),
  add column objetivo text check (objetivo is null or char_length(objetivo) <= 40);

-- Um mês de feed por cliente, como antes. Campanhas podem repetir o mesmo mês.
alter table vistto.meses drop constraint if exists meses_cliente_id_ano_mes_key;
create unique index meses_um_mes_por_cliente on vistto.meses(cliente_id, ano_mes) where canal = 'instagram';
create index meses_canal_idx on vistto.meses(cliente_id, canal, ano_mes);

-- ---------- 2. campos do anúncio ----------
alter table vistto.posts
  add column conjunto  text check (conjunto is null or char_length(conjunto) <= 80),
  add column publico   text check (publico is null or char_length(publico) <= 300),
  add column descricao text check (descricao is null or char_length(descricao) <= 300),
  add column cta       text check (cta is null or char_length(cta) <= 30),
  add column destino   text check (destino is null or (char_length(destino) <= 300 and destino ~ '^https://[^[:space:]]{4,}$'));
-- Anúncio de pesquisa do Google é só texto.
alter table vistto.posts drop constraint posts_tipo_check;
alter table vistto.posts add constraint posts_tipo_check check (tipo in ('carousel','image','reel','texto'));
create index posts_conjunto_idx on vistto.posts(mes_id, conjunto);

-- ---------- 3. quem enxerga cada canal ----------
create function vistto.pode_canal(a uuid, k text) returns boolean language sql stable security definer set search_path='' as $$
 select case when k = 'instagram' then vistto.meu_nivel(a) >= 1
   else vistto.meu_nivel(a) >= 2
     or exists(select 1 from vistto.agencia_usuarios where agencia_id=a and usuario_id=auth.uid() and papel='gestor_trafego') end;
$$;
create function vistto.canal_do_mes(m uuid) returns text language sql stable security definer set search_path='' as $$
 select canal from vistto.meses where id=m;
$$;
revoke all on function vistto.pode_canal(uuid,text),vistto.canal_do_mes(uuid) from public, anon;
grant execute on function vistto.pode_canal(uuid,text),vistto.canal_do_mes(uuid) to authenticated;

-- As regras dos posts continuam passando pela entrega, então basta fechar a entrega por canal.
drop policy meses_ler on vistto.meses;
drop policy meses_criar on vistto.meses;
drop policy meses_editar on vistto.meses;
drop policy meses_excluir on vistto.meses;
create policy meses_ler on vistto.meses for select to authenticated
  using (exists(select 1 from vistto.clientes c where c.id=cliente_id) and vistto.pode_canal(vistto.agencia_do_cliente(cliente_id), canal));
create policy meses_criar on vistto.meses for insert to authenticated
  with check (exists(select 1 from vistto.clientes c where c.id=cliente_id) and vistto.pode_canal(vistto.agencia_do_cliente(cliente_id), canal));
create policy meses_editar on vistto.meses for update to authenticated
  using (exists(select 1 from vistto.clientes c where c.id=cliente_id) and vistto.pode_canal(vistto.agencia_do_cliente(cliente_id), canal))
  with check (exists(select 1 from vistto.clientes c where c.id=cliente_id) and vistto.pode_canal(vistto.agencia_do_cliente(cliente_id), canal));
create policy meses_excluir on vistto.meses for delete to authenticated
  using (vistto.pode_gerir_cliente(cliente_id) and vistto.pode_canal(vistto.agencia_do_cliente(cliente_id), canal));

-- ---------- 4. arte do anúncio segue a mesma porta ----------
create or replace function vistto.pode_ref(v text) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.agencias a
   where vistto.midia_path(v) is not null and split_part(vistto.midia_path(v),'/',1)=a.id::text
     and (vistto.meu_nivel(a.id) >= 3 or (vistto.meu_nivel(a.id) >= 1 and (
       exists(select 1 from vistto.posts p join vistto.meses m on m.id=p.mes_id join vistto.clientes c on c.id=m.cliente_id
              where c.agencia_id=a.id and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id) and vistto.pode_canal(c.agencia_id,m.canal)
                and (v in (p.capa_url,p.video_url) or p.slides ? v))
       or exists(select 1 from vistto.clientes c where c.agencia_id=a.id and c.avatar_url=v and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id))
       or exists(select 1 from vistto.destaques d join vistto.clientes c on c.id=d.cliente_id
              where c.agencia_id=a.id and d.capa_url=v and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id))
     ))));
$$;
create or replace function vistto.pode_midia(n text) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from vistto.agencias a where (split_part(n,'/',1)=a.id::text or exists(select 1 from vistto.midia_legada l where l.path=n and l.agencia_id=a.id))
   and (vistto.meu_nivel(a.id) >= 3 or (vistto.meu_nivel(a.id) >= 1 and (
     exists(select 1 from vistto.posts p join vistto.meses m on m.id=p.mes_id join vistto.clientes c on c.id=m.cliente_id
            where c.agencia_id=a.id and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id) and vistto.pode_canal(c.agencia_id,m.canal)
              and (('midia:'||n) in (p.capa_url,p.video_url) or p.slides ? ('midia:'||n)))
     or exists(select 1 from vistto.clientes c where c.agencia_id=a.id and c.avatar_url=('midia:'||n) and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id))
     or exists(select 1 from vistto.destaques d join vistto.clientes c on c.id=d.cliente_id where c.agencia_id=a.id and d.capa_url=('midia:'||n) and vistto.pode_ver_c(c.agencia_id,c.squad_id,c.id))
   ))));
$$;

-- ---------- 5. a página do cliente ganha as abas ----------
drop function if exists vistto.get_mes(text,text);
create function vistto.get_mes(p_token text, p_ano_mes text default null, p_canal text default null, p_entrega uuid default null)
returns jsonb language plpgsql security definer set search_path = vistto as $$
declare c clientes; m meses; k text; canais jsonb; result jsonb;
begin
  select * into c from clientes where token = p_token;
  if c.id is null then return null; end if;

  select coalesce(jsonb_agg(jsonb_build_object('canal', x.canal, 'entregas', x.n)
      order by case x.canal when 'instagram' then 0 when 'meta' then 1 else 2 end), '[]')
    into canais
    from (select canal, count(*) n from meses where cliente_id = c.id and publicado group by canal) x;

  if p_entrega is not null then
    select * into m from meses where id = p_entrega and cliente_id = c.id and publicado;
  end if;
  k := coalesce(m.canal, nullif(p_canal, ''), 'instagram');
  if k not in ('instagram','meta','google') then k := 'instagram'; end if;
  if m.id is null then
    if p_canal is null and not exists(select 1 from meses where cliente_id = c.id and publicado and canal = k) then
      k := coalesce((select canal from meses where cliente_id = c.id and publicado
                      order by case canal when 'instagram' then 0 when 'meta' then 1 else 2 end limit 1), k);
    end if;
    select * into m from meses
      where cliente_id = c.id and publicado and canal = k
        and (p_ano_mes is null or ano_mes = p_ano_mes)
      order by ano_mes desc, created_at desc limit 1;
  end if;

  if m.id is null then
    return jsonb_build_object('cliente', jsonb_build_object('nome', c.nome), 'mes', null, 'canal', k, 'canais', canais,
      'agencia', (select to_jsonb(a) from agencias a where a.id = c.agencia_id));
  end if;

  select jsonb_build_object(
    'agencia', (select to_jsonb(a) from agencias a where a.id = c.agencia_id),
    'canal', m.canal, 'canais', canais,
    'cliente', jsonb_build_object('nome', c.nome, 'handle', c.handle, 'bio', c.bio, 'avatar_url', c.avatar_url),
    'mes', jsonb_build_object('id', m.id, 'ano_mes', m.ano_mes, 'titulo', m.titulo, 'intro', m.intro,
                              'canal', m.canal, 'objetivo', m.objetivo),
    'meses', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'ano_mes', ano_mes, 'titulo', titulo)
                       order by ano_mes desc, created_at desc), '[]')
                from meses where cliente_id = c.id and publicado and canal = m.canal),
    'destaques', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'capa_url', capa_url) order by ordem), '[]')
                    from destaques where cliente_id = c.id),
    'posts', (select coalesce(jsonb_agg(jsonb_build_object(
                'id', p.id, 'ordem', p.ordem, 'numero', p.numero, 'data', p.data, 'tema', p.tema,
                'titulo', p.titulo, 'tipo', p.tipo, 'legenda', p.legenda, 'slides', p.slides,
                'video_url', p.video_url, 'capa_url', p.capa_url, 'status', p.status,
                'conjunto', p.conjunto, 'publico', p.publico, 'descricao', p.descricao, 'cta', p.cta, 'destino', p.destino,
                'historico', (select coalesce(jsonb_agg(jsonb_build_object(
                                'acao', a.acao, 'comentario', a.comentario, 'autor', a.autor,
                                'origem', a.origem, 'created_at', a.created_at) order by a.created_at), '[]')
                              from aprovacoes a where a.post_id = p.id)
              ) order by p.ordem), '[]') from posts p where p.mes_id = m.id)
  ) into result;
  return result;
end $$;
revoke all on function vistto.get_mes(text,text,text,uuid) from public, anon, authenticated;
grant execute on function vistto.get_mes(text,text,text,uuid) to service_role;
commit;

-- ---------- pauta da equipe e LinkedIn (supabase/historico/pauta-e-linkedin.sql) ----------
-- Vistto · pauta da equipe. Rode uma vez no SQL Editor do Supabase (pode rodar de novo, não estraga nada).
--  · posts.responsavel: quem da equipe cuida do post (precisa ser da agência do post).
--  · posts.interno: 'revisao' (o Head aprova antes do cliente ver) ou 'reserva' (gaveta). Vazio = vai para o link.
--    Post com interno preenchido não aparece no link do cliente, e o cliente não consegue responder a ele.
--    Só Head, sócio e dono tiram um post da revisão interna.
--  · meses.publicado_em: quando o mês foi publicado, para medir quanto o cliente demora a responder.
--  · membros_agencia(): nomes da equipe para escolher o responsável (qualquer pessoa da agência enxerga).
--  · LinkedIn entra como canal de posts, igual ao feed: um mês por cliente, toda a equipe vê.
--    Meta Ads e Google Ads saem do link do cliente. As campanhas antigas continuam guardadas, nada é apagado.
begin;

alter table vistto.posts add column if not exists responsavel uuid references auth.users(id) on delete set null;
alter table vistto.posts add column if not exists interno text;
alter table vistto.posts drop constraint if exists posts_interno_valido;
alter table vistto.posts add constraint posts_interno_valido check (interno is null or interno in ('revisao','reserva'));
create index if not exists posts_responsavel_idx on vistto.posts(responsavel) where responsavel is not null;
alter table vistto.meses add column if not exists publicado_em timestamptz;

-- ---------- LinkedIn ----------
alter table vistto.meses drop constraint if exists meses_canal_check;
alter table vistto.meses add constraint meses_canal_check check (canal in ('instagram','linkedin','meta','google'));
create unique index if not exists meses_um_linkedin_por_mes on vistto.meses(cliente_id, ano_mes) where canal = 'linkedin';
create or replace function vistto.pode_canal(a uuid, k text) returns boolean language sql stable security definer set search_path='' as $$
 select case when k in ('instagram','linkedin') then vistto.meu_nivel(a) >= 1
   else vistto.meu_nivel(a) >= 2
     or exists(select 1 from vistto.agencia_usuarios where agencia_id=a and usuario_id=auth.uid() and papel='gestor_trafego') end;
$$;

-- ---------- pauta ----------
create or replace function vistto.validar_pauta() returns trigger language plpgsql security definer set search_path='' as $$
declare cli uuid; ag uuid;
begin
 select m.cliente_id, c.agencia_id into cli, ag from vistto.meses m join vistto.clientes c on c.id = m.cliente_id where m.id = new.mes_id;
 if new.responsavel is not null and (tg_op = 'INSERT' or new.responsavel is distinct from old.responsavel)
    and not exists (select 1 from vistto.agencia_usuarios u where u.agencia_id = ag and u.usuario_id = new.responsavel) then
   raise exception 'O responsável precisa ser da equipe da agência.';
 end if;
 if auth.uid() is not null and tg_op = 'UPDATE' and old.interno = 'revisao' and new.interno is null
    and not vistto.pode_gerir_cliente(cli) then
   raise exception 'Só Head, sócio ou dono liberam um post da revisão interna.';
 end if;
 return new;
end $$;
drop trigger if exists validar_pauta on vistto.posts;
create trigger validar_pauta before insert or update on vistto.posts for each row execute function vistto.validar_pauta();

create or replace function vistto.marcar_publicacao() returns trigger language plpgsql set search_path='' as $$
begin
 if new.publicado and (tg_op = 'INSERT' or not coalesce(old.publicado, false)) then new.publicado_em := now(); end if;
 return new;
end $$;
drop trigger if exists marcar_publicacao on vistto.meses;
create trigger marcar_publicacao before insert or update of publicado on vistto.meses for each row execute function vistto.marcar_publicacao();

create or replace function vistto.membros_agencia(p_agencia uuid) returns jsonb language sql stable security definer set search_path='' as $$
 select case when vistto.pode_agencia(p_agencia) then coalesce((
   select jsonb_agg(jsonb_build_object('usuario_id', m.usuario_id, 'nome', coalesce(nullif(trim(m.nome), ''), split_part(u.email, '@', 1)), 'papel', m.papel)
     order by coalesce(nullif(trim(m.nome), ''), u.email))
   from vistto.agencia_usuarios m join auth.users u on u.id = m.usuario_id
   where m.agencia_id = p_agencia), '[]'::jsonb) else '[]'::jsonb end
$$;
revoke all on function vistto.validar_pauta(), vistto.marcar_publicacao() from public, anon, authenticated;
revoke all on function vistto.membros_agencia(uuid) from public, anon;
grant execute on function vistto.membros_agencia(uuid) to authenticated;

-- O cliente responde só a post que está no link.
create or replace function vistto.registrar_aprovacao(p_token text, p_post_id uuid, p_acao text, p_comentario text default null, p_autor text default null)
returns jsonb language plpgsql security definer set search_path = vistto as $$
declare ok boolean;
begin
  select exists (
    select 1 from posts p join meses m on m.id = p.mes_id join clientes c on c.id = m.cliente_id
     where p.id = p_post_id and c.token = p_token and m.publicado and p.interno is null and m.canal in ('instagram','linkedin')
  ) into ok;
  if not ok then raise exception 'token inválido'; end if;
  if p_acao not in ('aprovado','ajuste','comentario') then raise exception 'ação inválida'; end if;
  if p_acao in ('ajuste','comentario') and coalesce(trim(p_comentario),'') = '' then raise exception 'descreva o ajuste'; end if;
  if length(p_comentario)>10000 or length(p_autor)>150 then raise exception 'Texto muito longo'; end if;
  insert into aprovacoes (post_id, acao, comentario, autor, origem)
    values (p_post_id, p_acao, nullif(trim(p_comentario),''), nullif(trim(p_autor),''), 'cliente');
  if p_acao in ('aprovado','ajuste') then
    perform set_config('vistto.status_ok','1',true);
    update posts set status = p_acao where id = p_post_id;
    perform set_config('vistto.status_ok','',true);
  end if;
  return jsonb_build_object('ok', true, 'status', (select status from posts where id = p_post_id));
end $$;
revoke all on function vistto.registrar_aprovacao(text,uuid,text,text,text) from public;
grant execute on function vistto.registrar_aprovacao(text,uuid,text,text,text) to anon, authenticated;

-- O link do cliente mostra feed e LinkedIn, sem post em revisão interna nem na gaveta.
create or replace function vistto.get_mes(p_token text, p_ano_mes text default null, p_canal text default null, p_entrega uuid default null)
returns jsonb language plpgsql security definer set search_path = vistto as $$
declare c clientes; m meses; k text; canais jsonb; result jsonb;
begin
  select * into c from clientes where token = p_token;
  if c.id is null then return null; end if;

  select coalesce(jsonb_agg(jsonb_build_object('canal', x.canal, 'entregas', x.n)
      order by case x.canal when 'instagram' then 0 else 1 end), '[]')
    into canais
    from (select canal, count(*) n from meses where cliente_id = c.id and publicado and canal in ('instagram','linkedin') group by canal) x;

  if p_entrega is not null then
    select * into m from meses where id = p_entrega and cliente_id = c.id and publicado and canal in ('instagram','linkedin');
  end if;
  k := coalesce(m.canal, nullif(p_canal, ''), 'instagram');
  if k not in ('instagram','linkedin') then k := 'instagram'; end if;
  if m.id is null then
    if p_canal is null and not exists(select 1 from meses where cliente_id = c.id and publicado and canal = k) then
      k := coalesce((select canal from meses where cliente_id = c.id and publicado and canal in ('instagram','linkedin')
                      order by case canal when 'instagram' then 0 else 1 end limit 1), k);
    end if;
    select * into m from meses
      where cliente_id = c.id and publicado and canal = k
        and (p_ano_mes is null or ano_mes = p_ano_mes)
      order by ano_mes desc, created_at desc limit 1;
  end if;

  if m.id is null then
    return jsonb_build_object('cliente', jsonb_build_object('nome', c.nome), 'mes', null, 'canal', k, 'canais', canais,
      'agencia', (select to_jsonb(a) from agencias a where a.id = c.agencia_id));
  end if;

  select jsonb_build_object(
    'agencia', (select to_jsonb(a) from agencias a where a.id = c.agencia_id),
    'canal', m.canal, 'canais', canais,
    'cliente', jsonb_build_object('nome', c.nome, 'handle', c.handle, 'bio', c.bio, 'avatar_url', c.avatar_url),
    'mes', jsonb_build_object('id', m.id, 'ano_mes', m.ano_mes, 'titulo', m.titulo, 'intro', m.intro,
                              'canal', m.canal, 'objetivo', m.objetivo),
    'meses', (select coalesce(jsonb_agg(jsonb_build_object('id', id, 'ano_mes', ano_mes, 'titulo', titulo)
                       order by ano_mes desc, created_at desc), '[]')
                from meses where cliente_id = c.id and publicado and canal = m.canal),
    'destaques', (select coalesce(jsonb_agg(jsonb_build_object('nome', nome, 'capa_url', capa_url) order by ordem), '[]')
                    from destaques where cliente_id = c.id),
    'posts', (select coalesce(jsonb_agg(jsonb_build_object(
                'id', p.id, 'ordem', p.ordem, 'numero', p.numero, 'data', p.data, 'tema', p.tema,
                'titulo', p.titulo, 'tipo', p.tipo, 'legenda', p.legenda, 'slides', p.slides,
                'video_url', p.video_url, 'capa_url', p.capa_url, 'status', p.status,
                'conjunto', p.conjunto, 'publico', p.publico, 'descricao', p.descricao, 'cta', p.cta, 'destino', p.destino,
                'historico', (select coalesce(jsonb_agg(jsonb_build_object(
                                'acao', a.acao, 'comentario', a.comentario, 'autor', a.autor,
                                'origem', a.origem, 'created_at', a.created_at) order by a.created_at), '[]')
                              from aprovacoes a where a.post_id = p.id)
              ) order by p.ordem), '[]') from posts p where p.mes_id = m.id and p.interno is null)
  ) into result;
  return result;
end $$;
revoke all on function vistto.get_mes(text,text,text,uuid) from public, anon, authenticated;
grant execute on function vistto.get_mes(text,text,text,uuid) to service_role;

commit;

-- ---------- link curto do cliente (supabase/historico/link-curto.sql) ----------
-- Vistto · link curto do cliente: visttoapp.github.io/c#prime-plus/k7f3q2m9/outubro-2026
-- Rode uma vez no SQL Editor do Supabase (pode rodar de novo, não estraga nada).
--  · clientes.codigo: 8 letras que, junto com o identificador do cliente (slug), abrem o link. Só Head+ vê.
--  · "Gerar novo link" troca o token e o código: os dois links antigos param de abrir.
--  · resolver_link(): a função "cliente" troca identificador + código pelo token. Só o servidor chama.
begin;

create or replace function vistto.novo_codigo() returns text language sql volatile set search_path='' as $$
 select string_agg(substr('abcdefghjkmnpqrstuvwxyz23456789', (get_byte(x.b, i) % 31) + 1, 1), '' order by i)
   from (select extensions.gen_random_bytes(8) b) x, generate_series(0, 7) i
$$;
grant execute on function vistto.novo_codigo() to authenticated;

alter table vistto.clientes add column if not exists codigo text;
update vistto.clientes set codigo = vistto.novo_codigo() where codigo is null;
alter table vistto.clientes alter column codigo set default vistto.novo_codigo();
alter table vistto.clientes alter column codigo set not null;
alter table vistto.clientes drop constraint if exists clientes_codigo_valido;
alter table vistto.clientes add constraint clientes_codigo_valido check (codigo ~ '^[a-z2-9]{8}$');
create unique index if not exists clientes_link_curto on vistto.clientes(slug, codigo);
-- a coluna não entra no grant de leitura da tabela: a equipe não vê o código, como já não vê o token

create or replace function vistto.renovar_link(p_cliente uuid) returns text language plpgsql security definer set search_path='vistto' as $$
declare t text; begin
 if not vistto.pode_gerir_cliente(p_cliente) then raise exception 'Acesso negado'; end if;
 t := encode(extensions.gen_random_bytes(32), 'hex');
 update clientes set token = t, codigo = vistto.novo_codigo() where id = p_cliente;
 return t;
end $$;

create or replace function vistto.link_curto(p_cliente uuid) returns text language plpgsql stable security definer set search_path='' as $$
begin
 if not vistto.pode_gerir_cliente(p_cliente) then raise exception 'Acesso negado'; end if;
 return (select codigo from vistto.clientes where id = p_cliente);
end $$;
revoke all on function vistto.link_curto(uuid) from public, anon;
grant execute on function vistto.link_curto(uuid) to authenticated;

create or replace function vistto.resolver_link(p_slug text, p_codigo text) returns text language sql stable security definer set search_path='' as $$
 select token from vistto.clientes where slug = lower(trim(p_slug)) and codigo = lower(trim(p_codigo)) limit 1
$$;
revoke all on function vistto.resolver_link(text, text) from public, anon, authenticated;
grant execute on function vistto.resolver_link(text, text) to service_role;

commit;
reset search_path;
